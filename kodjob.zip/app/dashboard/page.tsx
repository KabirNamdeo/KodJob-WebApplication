"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useRouter } from "next/navigation"
import Image from "next/image"
import {
  Briefcase,
  LogOut,
  Menu,
  Search,
  User,
  X,
  MapPin,
  Building,
  DollarSign,
  Filter,
  ChevronRight,
  BarChart3,
  BookmarkCheck,
  Bell,
  Calendar,
  Bookmark,
  FileCheck2,
  Settings,
  UserPlus,
  Trophy,
  BookOpen,
  Code,
  Lightbulb,
  FileText,
  Quote,
  Compass,
  Sparkles,
  Rocket,
  Brain,
  Target,
  Presentation,
  Workflow,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  fetchJobs,
  getContests,
  getOpportunities,
  getPreparationResources,
  getCareerGuidance,
  getInspirationQuotes,
} from "@/lib/api"
import { useAuth } from "@/context/auth-context"
import { getUserProfile } from "@/lib/auth"
import type {
  JobType,
  ContestType,
  OpportunityType,
  PreparationResourceType,
  CareerGuidanceType,
  InspirationQuoteType,
} from "@/lib/types"

export default function Dashboard() {
  const router = useRouter()
  const { user, logout } = useAuth()
  const [jobs, setJobs] = useState<JobType[]>([])
  const [contests, setContests] = useState<ContestType[]>([])
  const [opportunities, setOpportunities] = useState<OpportunityType[]>([])
  const [preparationResources, setPreparationResources] = useState<PreparationResourceType[]>([])
  const [careerGuidance, setCareerGuidance] = useState<CareerGuidanceType[]>([])
  const [inspirationQuotes, setInspirationQuotes] = useState<InspirationQuoteType[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedJob, setSelectedJob] = useState<JobType | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("overview")
  const [userProfile, setUserProfile] = useState<any>(null)
  const [profileCompletion, setProfileCompletion] = useState(0)
  const [searchCategory, setSearchCategory] = useState("jobs")

  useEffect(() => {
    // Redirect if not logged in
    if (!user) {
      router.push("/")
      return
    }

    const loadData = async () => {
      try {
        // Load jobs
        const jobsData = await fetchJobs()
        setJobs(jobsData)

        // Load contests
        const contestsData = await getContests()
        setContests(contestsData)

        // Load opportunities
        const opportunitiesData = await getOpportunities()
        setOpportunities(opportunitiesData)

        // Load preparation resources
        const resourcesData = await getPreparationResources()
        setPreparationResources(resourcesData)

        // Load career guidance
        const guidanceData = await getCareerGuidance()
        setCareerGuidance(guidanceData)

        // Load inspiration quotes
        const quotesData = await getInspirationQuotes()
        setInspirationQuotes(quotesData)

        // Load user profile
        const profile = await getUserProfile(user.id)
        setUserProfile(profile)

        // Calculate profile completion
        if (profile) {
          let completedFields = 0
          let totalFields = 0

          // Count completed fields
          const personalFields = ["fullName", "email", "phone", "location", "bio", "photo"]
          personalFields.forEach((field) => {
            totalFields++
            if (profile[field] && typeof profile[field] === "string" && profile[field].trim() !== "") {
              completedFields++
            }
          })

          // Education
          if (
            profile.education &&
            profile.education.length > 0 &&
            profile.education[0].degree &&
            profile.education[0].institution
          ) {
            completedFields += 2
          }
          totalFields += 2

          // Experience
          if (
            profile.experience &&
            profile.experience.length > 0 &&
            profile.experience[0].title &&
            profile.experience[0].company
          ) {
            completedFields += 2
          }
          totalFields += 2

          // Skills
          if (profile.skills && profile.skills.length > 0 && profile.skills[0]) {
            completedFields++
          }
          totalFields++

          // Resume
          if (profile.resume) {
            completedFields++
          }
          totalFields++

          const percentage = Math.round((completedFields / totalFields) * 100)
          setProfileCompletion(percentage)
        }
      } catch (error) {
        console.error("Failed to fetch data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [user, router])

  const filteredJobs = jobs.filter(
    (job) =>
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.skills?.some((skill) => skill.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const filteredContests = contests.filter(
    (contest) =>
      contest.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contest.organizer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contest.type.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredOpportunities = opportunities.filter(
    (opportunity) =>
      opportunity.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      opportunity.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      opportunity.type.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredResources = preparationResources.filter(
    (resource) =>
      resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.category.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredGuidance = careerGuidance.filter(
    (guidance) =>
      guidance.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      guidance.category.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleSearch = () => {
    if (searchTerm.trim() === "") return

    if (searchCategory === "jobs") {
      setActiveTab("jobs")
    } else if (searchCategory === "contests") {
      setActiveTab("contests")
    } else if (searchCategory === "opportunities") {
      setActiveTab("opportunities")
    } else if (searchCategory === "resources") {
      setActiveTab("preparation")
    } else if (searchCategory === "guidance") {
      setActiveTab("career")
    }
  }

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  // Mock data for dashboard stats
  const stats = [
    { title: "Jobs Viewed", value: 24, icon: <Briefcase className="h-5 w-5 text-indigo-400" /> },
    { title: "Applications", value: 8, icon: <FileCheck2 className="h-5 w-5 text-green-400" /> },
    { title: "Saved Jobs", value: 12, icon: <Bookmark className="h-5 w-5 text-amber-400" /> },
    { title: "Interviews", value: 3, icon: <Calendar className="h-5 w-5 text-purple-400" /> },
  ]

  // Mock data for recent applications
  const recentApplications = [
    { id: "1", company: "TechCorp", position: "Senior Frontend Developer", date: "2 days ago", status: "In Review" },
    { id: "2", company: "DesignHub", position: "UX/UI Designer", date: "1 week ago", status: "Interview Scheduled" },
    { id: "3", company: "DataSystems", position: "Backend Engineer", date: "3 days ago", status: "Application Sent" },
  ]

  // Mock data for recommended jobs
  const recommendedJobs = jobs.slice(0, 3)

  // Mock data for upcoming contests
  const upcomingContests = contests.slice(0, 3)

  // Random quote for the dashboard
  const randomQuote =
    inspirationQuotes.length > 0
      ? inspirationQuotes[Math.floor(Math.random() * inspirationQuotes.length)]
      : { quote: "The only way to do great work is to love what you do.", author: "Steve Jobs" }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-gray-100">
      {/* Mobile Header */}
      <header className="md:hidden flex items-center justify-between p-4 bg-gray-800/80 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-30">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(true)}
            className="text-gray-300 hover:text-white"
          >
            <Menu />
          </Button>
          <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400">
            KodJob
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white relative">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full"></span>
          </Button>
          <Avatar className="h-8 w-8">
            <AvatarImage
              src={userProfile?.photo || `https://api.dicebear.com/7.x/initials/svg?seed=${user?.name}`}
              alt={user?.name || ""}
            />
            <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
          </Avatar>
        </div>
      </header>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", bounce: 0, duration: 0.4 }}
            className="fixed inset-0 z-50 bg-gray-900/80 backdrop-blur-sm md:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <motion.div
              className="fixed inset-y-0 left-0 w-3/4 max-w-xs bg-gray-800 border-r border-gray-700 p-6"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400">
                  KodJob
                </h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setSidebarOpen(false)}
                  className="text-gray-300 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="mb-8">
                <div className="flex items-center gap-3 mb-4">
                  <Avatar>
                    <AvatarImage
                      src={userProfile?.photo || `https://api.dicebear.com/7.x/initials/svg?seed=${user?.name}`}
                      alt={user?.name || ""}
                    />
                    <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-white">{user?.name}</p>
                    <p className="text-sm text-gray-400">{user?.email}</p>
                  </div>
                </div>

                <div className="bg-gray-700/30 rounded-lg p-3">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-300">Profile Completion</span>
                    <span className="text-sm font-medium text-indigo-400">{profileCompletion}%</span>
                  </div>
                  <Progress
                    value={profileCompletion}
                    className="h-1.5 bg-gray-700"
                    indicatorClassName="bg-gradient-to-r from-indigo-500 to-purple-500"
                  />
                </div>
              </div>

              <nav className="space-y-1">
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                  onClick={() => {
                    setActiveTab("overview")
                    setSidebarOpen(false)
                  }}
                >
                  <BarChart3 className="h-5 w-5" />
                  Dashboard
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                  onClick={() => {
                    setActiveTab("jobs")
                    setSidebarOpen(false)
                  }}
                >
                  <Briefcase className="h-5 w-5" />
                  Browse Jobs
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                  onClick={() => {
                    setActiveTab("contests")
                    setSidebarOpen(false)
                  }}
                >
                  <Trophy className="h-5 w-5" />
                  Contests
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                  onClick={() => {
                    setActiveTab("opportunities")
                    setSidebarOpen(false)
                  }}
                >
                  <Lightbulb className="h-5 w-5" />
                  Opportunities
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                  onClick={() => {
                    setActiveTab("preparation")
                    setSidebarOpen(false)
                  }}
                >
                  <BookOpen className="h-5 w-5" />
                  Preparation
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                  onClick={() => {
                    setActiveTab("practice")
                    setSidebarOpen(false)
                  }}
                >
                  <Code className="h-5 w-5" />
                  Practice
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                  onClick={() => {
                    setActiveTab("career")
                    setSidebarOpen(false)
                  }}
                >
                  <Compass className="h-5 w-5" />
                  Career Guidance
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                  onClick={() => {
                    setActiveTab("inspiration")
                    setSidebarOpen(false)
                  }}
                >
                  <Sparkles className="h-5 w-5" />
                  Inspiration
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                >
                  <BookmarkCheck className="h-5 w-5" />
                  Saved Jobs
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                >
                  <FileCheck2 className="h-5 w-5" />
                  Applications
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                  onClick={() => router.push("/profile/registration")}
                >
                  <User className="h-5 w-5" />
                  Profile
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                >
                  <Settings className="h-5 w-5" />
                  Settings
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
                  onClick={handleLogout}
                >
                  <LogOut className="h-5 w-5" />
                  Logout
                </Button>
              </nav>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex h-screen">
        {/* Desktop Sidebar */}
        <aside className="hidden md:flex flex-col w-64 bg-gray-800/50 backdrop-blur-sm border-r border-gray-700 p-5 sticky top-0 h-screen">
          <div className="mb-8">
            <h2 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400">
              KodJob
            </h2>
          </div>

          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <Avatar>
                <AvatarImage
                  src={userProfile?.photo || `https://api.dicebear.com/7.x/initials/svg?seed=${user?.name}`}
                  alt={user?.name || ""}
                />
                <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium text-white">{user?.name}</p>
                <p className="text-sm text-gray-400">{user?.email}</p>
              </div>
            </div>

            <div className="bg-gray-700/30 rounded-lg p-3">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-300">Profile Completion</span>
                <span className="text-sm font-medium text-indigo-400">{profileCompletion}%</span>
              </div>
              <Progress
                value={profileCompletion}
                className="h-1.5 bg-gray-700"
                indicatorClassName="bg-gradient-to-r from-indigo-500 to-purple-500"
              />
              {profileCompletion < 100 && (
                <Button
                  variant="link"
                  className="text-xs text-indigo-400 hover:text-indigo-300 p-0 h-auto mt-2"
                  onClick={() => router.push("/profile/registration")}
                >
                  Complete your profile
                </Button>
              )}
            </div>
          </div>

          <nav className="space-y-1 flex-1 overflow-y-auto">
            <Button
              variant={activeTab === "overview" ? "secondary" : "ghost"}
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
              onClick={() => setActiveTab("overview")}
            >
              <BarChart3 className="h-5 w-5" />
              Dashboard
            </Button>
            <Button
              variant={activeTab === "jobs" ? "secondary" : "ghost"}
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
              onClick={() => setActiveTab("jobs")}
            >
              <Briefcase className="h-5 w-5" />
              Browse Jobs
            </Button>
            <Button
              variant={activeTab === "contests" ? "secondary" : "ghost"}
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
              onClick={() => setActiveTab("contests")}
            >
              <Trophy className="h-5 w-5" />
              Contests
            </Button>
            <Button
              variant={activeTab === "opportunities" ? "secondary" : "ghost"}
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
              onClick={() => setActiveTab("opportunities")}
            >
              <Lightbulb className="h-5 w-5" />
              Opportunities
            </Button>
            <Button
              variant={activeTab === "preparation" ? "secondary" : "ghost"}
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
              onClick={() => setActiveTab("preparation")}
            >
              <BookOpen className="h-5 w-5" />
              Preparation
            </Button>
            <Button
              variant={activeTab === "practice" ? "secondary" : "ghost"}
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
              onClick={() => setActiveTab("practice")}
            >
              <Code className="h-5 w-5" />
              Practice
            </Button>
            <Button
              variant={activeTab === "career" ? "secondary" : "ghost"}
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
              onClick={() => setActiveTab("career")}
            >
              <Compass className="h-5 w-5" />
              Career Guidance
            </Button>
            <Button
              variant={activeTab === "inspiration" ? "secondary" : "ghost"}
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
              onClick={() => setActiveTab("inspiration")}
            >
              <Sparkles className="h-5 w-5" />
              Inspiration
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
            >
              <BookmarkCheck className="h-5 w-5" />
              Saved Jobs
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
            >
              <FileCheck2 className="h-5 w-5" />
              Applications
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
              onClick={() => router.push("/profile/registration")}
            >
              <User className="h-5 w-5" />
              Profile
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50"
            >
              <Settings className="h-5 w-5" />
              Settings
            </Button>
          </nav>

          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-gray-700/50 mt-auto"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5" />
            Logout
          </Button>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto p-4 md:p-6 pb-20">
          {/* Global Search Bar */}
          <div className="mb-6 max-w-3xl mx-auto">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search for jobs, contests, opportunities..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  className="pl-10 bg-gray-800/50 border-gray-700 text-gray-200 w-full"
                />
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="bg-gray-800/50 border-gray-700 text-gray-200">
                    {searchCategory === "jobs"
                      ? "Jobs"
                      : searchCategory === "contests"
                        ? "Contests"
                        : searchCategory === "opportunities"
                          ? "Opportunities"
                          : searchCategory === "resources"
                            ? "Resources"
                            : searchCategory === "guidance"
                              ? "Guidance"
                              : "All"}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-gray-800 border-gray-700 text-gray-200">
                  <DropdownMenuItem onClick={() => setSearchCategory("jobs")}>Jobs</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSearchCategory("contests")}>Contests</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSearchCategory("opportunities")}>Opportunities</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSearchCategory("resources")}>Resources</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSearchCategory("guidance")}>Career Guidance</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Button
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500"
                onClick={handleSearch}
              >
                Search
              </Button>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-4 md:grid-cols-8 mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="jobs">Jobs</TabsTrigger>
              <TabsTrigger value="contests">Contests</TabsTrigger>
              <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
              <TabsTrigger value="preparation">Preparation</TabsTrigger>
              <TabsTrigger value="practice">Practice</TabsTrigger>
              <TabsTrigger value="career">Career</TabsTrigger>
              <TabsTrigger value="inspiration">Inspiration</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              {/* Overview Tab Content */}
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-white">Dashboard</h1>
                  <p className="text-gray-400">Welcome back, {user?.name}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-gray-300 hover:text-white relative hidden md:flex"
                  >
                    <Bell className="h-5 w-5" />
                    <span className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full"></span>
                  </Button>
                  <Button
                    className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500"
                    onClick={() => router.push("/profile/registration")}
                  >
                    {profileCompletion < 100 ? (
                      <>
                        <UserPlus className="h-4 w-4 mr-2" />
                        Complete Profile
                      </>
                    ) : (
                      <>
                        <FileCheck2 className="h-4 w-4 mr-2" />
                        Update Resume
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Inspirational Quote */}
              <Card className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 border-gray-700 backdrop-blur-sm mb-6">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <Quote className="h-8 w-8 text-indigo-400" />
                    <div>
                      <p className="text-lg font-medium text-white italic">"{randomQuote.quote}"</p>
                      <p className="text-sm text-gray-300 mt-1">— {randomQuote.author}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Stats Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {stats.map((stat, index) => (
                  <Card key={index} className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-gray-400 text-sm">{stat.title}</p>
                          <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
                        </div>
                        <div className="h-12 w-12 rounded-full bg-gray-700/50 flex items-center justify-center">
                          {stat.icon}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Profile Completion Alert */}
              {profileCompletion < 70 && (
                <Card className="bg-indigo-500/10 border-indigo-500/30 mb-6">
                  <CardContent className="p-4 flex items-start gap-4">
                    <div className="h-10 w-10 rounded-full bg-indigo-500/20 flex items-center justify-center flex-shrink-0">
                      <UserPlus className="h-5 w-5 text-indigo-400" />
                    </div>
                    <div>
                      <h3 className="font-medium text-white mb-1">Complete Your Profile</h3>
                      <p className="text-gray-300 text-sm mb-3">
                        Your profile is only {profileCompletion}% complete. A complete profile increases your chances of
                        getting hired.
                      </p>
                      <Button
                        size="sm"
                        className="bg-indigo-600 hover:bg-indigo-500 text-white"
                        onClick={() => router.push("/profile/registration")}
                      >
                        Complete Now
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Two Column Layout */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Recent Applications */}
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm lg:col-span-2">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium">Recent Applications</CardTitle>
                    <CardDescription>Track the status of your job applications</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentApplications.map((app, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-md bg-gray-700 flex items-center justify-center text-white font-medium">
                              {app.company.charAt(0)}
                            </div>
                            <div>
                              <p className="font-medium text-white">{app.position}</p>
                              <p className="text-sm text-gray-400">
                                {app.company} • {app.date}
                              </p>
                            </div>
                          </div>
                          <Badge
                            className={
                              app.status === "Interview Scheduled"
                                ? "bg-green-500/20 text-green-300 hover:bg-green-500/30"
                                : app.status === "In Review"
                                  ? "bg-amber-500/20 text-amber-300 hover:bg-amber-500/30"
                                  : "bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/30"
                            }
                          >
                            {app.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="pt-0">
                    <Button
                      variant="ghost"
                      className="w-full text-indigo-400 hover:text-indigo-300 hover:bg-gray-700/50"
                    >
                      View All Applications
                    </Button>
                  </CardFooter>
                </Card>

                {/* Upcoming Contests */}
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium">Upcoming Contests</CardTitle>
                    <CardDescription>Participate to improve your skills</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {upcomingContests.map((contest, index) => (
                        <div key={index} className="p-3 bg-gray-700/30 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium text-white">{contest.title}</h4>
                            <Badge variant="outline" className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                              {contest.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-400 mb-2">
                            {contest.organizer} • {contest.date}
                          </p>
                          <div className="flex justify-between items-center">
                            <span className="text-xs text-gray-400">{contest.participants} participants</span>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-xs h-7 border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                            >
                              Register
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="pt-0">
                    <Button
                      variant="ghost"
                      className="w-full text-indigo-400 hover:text-indigo-300 hover:bg-gray-700/50"
                      onClick={() => setActiveTab("contests")}
                    >
                      View All Contests
                    </Button>
                  </CardFooter>
                </Card>
              </div>

              {/* Recommended Jobs */}
              <h2 className="text-xl font-bold mt-8 mb-4">Recommended For You</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recommendedJobs.map((job, index) => (
                  <motion.div
                    key={job.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="group relative bg-white/5 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 hover:border-indigo-500/50 transition-all duration-300 hover:shadow-[0_0_15px_rgba(99,102,241,0.1)]"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/5 to-purple-600/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                    <div className="flex items-start justify-between mb-4">
                      <div className="h-12 w-12 bg-gray-700 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                        {job.company.charAt(0)}
                      </div>
                      <span className="text-xs font-medium px-2 py-1 rounded-full bg-indigo-500/20 text-indigo-300">
                        {job.type}
                      </span>
                    </div>

                    <h3 className="text-lg font-semibold mb-1 text-white">{job.title}</h3>
                    <p className="text-gray-400 text-sm mb-3 flex items-center gap-1">
                      <Building className="h-3 w-3" /> {job.company}
                    </p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-gray-400 text-sm">
                        <MapPin className="h-3 w-3 mr-2" /> {job.location}
                      </div>
                      <div className="flex items-center text-gray-400 text-sm">
                        <DollarSign className="h-3 w-3 mr-2" /> {job.salary}
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {job.skills?.slice(0, 2).map((skill, idx) => (
                        <Badge
                          key={idx}
                          variant="outline"
                          className="bg-gray-800/30 border-gray-700/50 text-gray-300 text-xs"
                        >
                          {skill}
                        </Badge>
                      ))}
                      {job.skills && job.skills.length > 2 && (
                        <Badge variant="outline" className="bg-gray-800/30 border-gray-700/50 text-gray-300 text-xs">
                          +{job.skills.length - 2} more
                        </Badge>
                      )}
                    </div>

                    <Button
                      className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 group-hover:shadow-lg transition-all duration-300"
                      onClick={() => router.push(`/job/${job.id}/apply`)}
                    >
                      <span>Apply Now</span>
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </motion.div>
                ))}
              </div>

              <div className="mt-4 text-center">
                <Button
                  variant="outline"
                  className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                  onClick={() => setActiveTab("jobs")}
                >
                  Browse All Jobs
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="jobs">
              {/* Jobs Tab Content */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-white">Browse Jobs</h1>
                  <p className="text-gray-400">Explore exciting job opportunities</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="relative flex-1 md:w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      type="text"
                      placeholder="Search jobs..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-gray-800/50 border-gray-700 text-gray-200 w-full"
                    />
                  </div>
                  <Button
                    variant="outline"
                    className="hidden md:flex items-center gap-2 bg-gray-800/50 border-gray-700 text-gray-200"
                  >
                    <Filter className="h-3.5 w-3.5" />
                    Filters
                  </Button>
                </div>
              </div>

              {/* Job Listings */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredJobs.map((job, index) => (
                  <motion.div
                    key={job.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="group relative bg-white/5 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 hover:border-indigo-500/50 transition-all duration-300 hover:shadow-[0_0_15px_rgba(99,102,241,0.1)]"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/5 to-purple-600/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                    <div className="flex items-start justify-between mb-4">
                      <div className="h-12 w-12 bg-gray-700 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                        {job.company.charAt(0)}
                      </div>
                      <span className="text-xs font-medium px-2 py-1 rounded-full bg-indigo-500/20 text-indigo-300">
                        {job.type}
                      </span>
                    </div>

                    <h3 className="text-lg font-semibold mb-1 text-white">{job.title}</h3>
                    <p className="text-gray-400 text-sm mb-3 flex items-center gap-1">
                      <Building className="h-3 w-3" /> {job.company}
                    </p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-gray-400 text-sm">
                        <MapPin className="h-3 w-3 mr-2" /> {job.location}
                      </div>
                      <div className="flex items-center text-gray-400 text-sm">
                        <DollarSign className="h-3 w-3 mr-2" /> {job.salary}
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {job.skills?.slice(0, 2).map((skill, idx) => (
                        <Badge
                          key={idx}
                          variant="outline"
                          className="bg-gray-800/30 border-gray-700/50 text-gray-300 text-xs"
                        >
                          {skill}
                        </Badge>
                      ))}
                      {job.skills && job.skills.length > 2 && (
                        <Badge variant="outline" className="bg-gray-800/30 border-gray-700/50 text-gray-300 text-xs">
                          +{job.skills.length - 2} more
                        </Badge>
                      )}
                    </div>

                    <Button
                      className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 group-hover:shadow-lg transition-all duration-300"
                      onClick={() => router.push(`/job/${job.id}/apply`)}
                    >
                      <span>Apply Now</span>
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="contests">
              {/* Contests Tab Content */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-white">Contests</h1>
                  <p className="text-gray-400">Participate in coding contests and challenges</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="relative flex-1 md:w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      type="text"
                      placeholder="Search contests..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-gray-800/50 border-gray-700 text-gray-200 w-full"
                    />
                  </div>
                  <Button
                    variant="outline"
                    className="hidden md:flex items-center gap-2 bg-gray-800/50 border-gray-700 text-gray-200"
                  >
                    <Filter className="h-3.5 w-3.5" />
                    Filters
                  </Button>
                </div>
              </div>

              {/* Contest Listings */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredContests.map((contest, index) => (
                  <motion.div
                    key={contest.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="group relative bg-white/5 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 hover:border-indigo-500/50 transition-all duration-300 hover:shadow-[0_0_15px_rgba(99,102,241,0.1)]"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/5 to-purple-600/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                    <div className="flex items-start justify-between mb-4">
                      <div className="h-12 w-12 bg-gray-700 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                        {contest.organizer.charAt(0)}
                      </div>
                      <span className="text-xs font-medium px-2 py-1 rounded-full bg-purple-500/20 text-purple-300">
                        {contest.type}
                      </span>
                    </div>

                    <h3 className="text-lg font-semibold mb-1 text-white">{contest.title}</h3>
                    <p className="text-gray-400 text-sm mb-3 flex items-center gap-1">
                      <User className="h-3 w-3" /> {contest.organizer}
                    </p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-gray-400 text-sm">
                        <Calendar className="h-3 w-3 mr-2" /> {contest.date}
                      </div>
                      <div className="flex items-center text-gray-400 text-sm">
                        <UserPlus className="h-3 w-3 mr-2" /> {contest.participants} participants
                      </div>
                    </div>

                    <Button
                      className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 group-hover:shadow-lg transition-all duration-300"
                      onClick={() => {}}
                    >
                      <span>Register Now</span>
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="opportunities">
              {/* Opportunities Tab Content */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-white">Opportunities</h1>
                  <p className="text-gray-400">Explore internships, scholarships, and more</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="relative flex-1 md:w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      type="text"
                      placeholder="Search opportunities..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-gray-800/50 border-gray-700 text-gray-200 w-full"
                    />
                  </div>
                  <Button
                    variant="outline"
                    className="hidden md:flex items-center gap-2 bg-gray-800/50 border-gray-700 text-gray-200"
                  >
                    <Filter className="h-3.5 w-3.5" />
                    Filters
                  </Button>
                </div>
              </div>

              {/* Opportunity Listings */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredOpportunities.map((opportunity, index) => (
                  <motion.div
                    key={opportunity.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="group relative bg-white/5 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 hover:border-indigo-500/50 transition-all duration-300 hover:shadow-[0_0_15px_rgba(99,102,241,0.1)]"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/5 to-purple-600/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                    <div className="flex items-start justify-between mb-4">
                      <div className="h-12 w-12 bg-gray-700 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                        {opportunity.company.charAt(0)}
                      </div>
                      <span className="text-xs font-medium px-2 py-1 rounded-full bg-amber-500/20 text-amber-300">
                        {opportunity.type}
                      </span>
                    </div>

                    <h3 className="text-lg font-semibold mb-1 text-white">{opportunity.title}</h3>
                    <p className="text-gray-400 text-sm mb-3 flex items-center gap-1">
                      <Building className="h-3 w-3" /> {opportunity.company}
                    </p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-gray-400 text-sm">
                        <MapPin className="h-3 w-3 mr-2" /> {opportunity.location}
                      </div>
                      <div className="flex items-center text-gray-400 text-sm">
                        <Calendar className="h-3 w-3 mr-2" /> {opportunity.deadline}
                      </div>
                    </div>

                    <Button
                      className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 group-hover:shadow-lg transition-all duration-300"
                      onClick={() => {}}
                    >
                      <span>Apply Now</span>
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="preparation">
              {/* Preparation Tab Content */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-white">Preparation</h1>
                  <p className="text-gray-400">Resources to help you prepare for your career</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="relative flex-1 md:w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      type="text"
                      placeholder="Search resources..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-gray-800/50 border-gray-700 text-gray-200 w-full"
                    />
                  </div>
                  <Button
                    variant="outline"
                    className="hidden md:flex items-center gap-2 bg-gray-800/50 border-gray-700 text-gray-200"
                  >
                    <Filter className="h-3.5 w-3.5" />
                    Filters
                  </Button>
                </div>
              </div>

              {/* Resource Listings */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredResources.map((resource, index) => (
                  <motion.div
                    key={resource.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="group relative bg-white/5 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 hover:border-indigo-500/50 transition-all duration-300 hover:shadow-[0_0_15px_rgba(99,102,241,0.1)]"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/5 to-purple-600/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                    <div className="flex items-start justify-between mb-4">
                      <div className="h-12 w-12 bg-gray-700 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                        {resource.category.charAt(0)}
                      </div>
                      <span className="text-xs font-medium px-2 py-1 rounded-full bg-green-500/20 text-green-300">
                        {resource.category}
                      </span>
                    </div>

                    <h3 className="text-lg font-semibold mb-1 text-white">{resource.title}</h3>
                    <p className="text-gray-400 text-sm mb-3 flex items-center gap-1">
                      <BookOpen className="h-3 w-3" /> {resource.type}
                    </p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-gray-400 text-sm">
                        <FileText className="h-3 w-3 mr-2" /> {resource.duration}
                      </div>
                      <div className="flex items-center text-gray-400 text-sm">
                        <UserPlus className="h-3 w-3 mr-2" /> {resource.level}
                      </div>
                    </div>

                    <Button
                      className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 group-hover:shadow-lg transition-all duration-300"
                      onClick={() => {}}
                    >
                      <span>View Resource</span>
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="practice">
              {/* Practice Tab Content */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-white">Practice</h1>
                  <p className="text-gray-400">Enhance your coding skills with our curated problems</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="relative flex-1 md:w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      type="text"
                      placeholder="Search problems..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-gray-800/50 border-gray-700 text-gray-200 w-full"
                    />
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="bg-gray-800/50 border-gray-700 text-gray-200">
                        All Topics
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-gray-800 border-gray-700 text-gray-200">
                      <DropdownMenuItem>Java</DropdownMenuItem>
                      <DropdownMenuItem>Python</DropdownMenuItem>
                      <DropdownMenuItem>Data Structures</DropdownMenuItem>
                      <DropdownMenuItem>Algorithms</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              {/* Java Section */}
              <div className="mb-8">
                <h2 className="text-xl font-bold mb-4">Java Programming</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-blue-500/20 flex items-center justify-center">
                          <Code className="h-6 w-6 text-blue-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-white">Java Basics</h3>
                          <Badge className="bg-green-500/20 text-green-300">Easy</Badge>
                        </div>
                      </div>
                      <ul className="space-y-2 text-gray-300 text-sm mb-4">
                        <li>• Object-Oriented Programming concepts</li>
                        <li>• Exception Handling</li>
                        <li>• Collections Framework</li>
                        <li>• Multithreading basics</li>
                      </ul>
                      <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600">Start Practice</Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-yellow-500/20 flex items-center justify-center">
                          <Code className="h-6 w-6 text-yellow-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-white">Advanced Java</h3>
                          <Badge className="bg-yellow-500/20 text-yellow-300">Medium</Badge>
                        </div>
                      </div>
                      <ul className="space-y-2 text-gray-300 text-sm mb-4">
                        <li>• Design Patterns</li>
                        <li>• Spring Framework</li>
                        <li>• Java Stream API</li>
                        <li>• Concurrency</li>
                      </ul>
                      <Button className="w-full bg-gradient-to-r from-yellow-600 to-orange-600">Start Practice</Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-red-500/20 flex items-center justify-center">
                          <Code className="h-6 w-6 text-red-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-white">Enterprise Java</h3>
                          <Badge className="bg-red-500/20 text-red-300">Hard</Badge>
                        </div>
                      </div>
                      <ul className="space-y-2 text-gray-300 text-sm mb-4">
                        <li>• Microservices Architecture</li>
                        <li>• Spring Boot & Cloud</li>
                        <li>• Performance Optimization</li>
                        <li>• Security Patterns</li>
                      </ul>
                      <Button className="w-full bg-gradient-to-r from-red-600 to-pink-600">Start Practice</Button>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Python Section */}
              <div className="mb-8">
                <h2 className="text-xl font-bold mb-4">Python Programming</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-green-500/20 flex items-center justify-center">
                          <Code className="h-6 w-6 text-green-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-white">Python Basics</h3>
                          <Badge className="bg-green-500/20 text-green-300">Easy</Badge>
                        </div>
                      </div>
                      <ul className="space-y-2 text-gray-300 text-sm mb-4">
                        <li>• Data Types & Structures</li>
                        <li>• Control Flow</li>
                        <li>• Functions & Modules</li>
                        <li>• File Handling</li>
                      </ul>
                      <Button className="w-full bg-gradient-to-r from-green-600 to-emerald-600">Start Practice</Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                          <Code className="h-6 w-6 text-purple-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-white">Advanced Python</h3>
                          <Badge className="bg-purple-500/20 text-purple-300">Medium</Badge>
                        </div>
                      </div>
                      <ul className="space-y-2 text-gray-300 text-sm mb-4">
                        <li>• Decorators & Generators</li>
                        <li>• Context Managers</li>
                        <li>• Async Programming</li>
                        <li>• Meta Programming</li>
                      </ul>
                      <Button className="w-full bg-gradient-to-r from-purple-600 to-indigo-600">Start Practice</Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-pink-500/20 flex items-center justify-center">
                          <Code className="h-6 w-6 text-pink-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-white">Python Projects</h3>
                          <Badge className="bg-pink-500/20 text-pink-300">Hard</Badge>
                        </div>
                      </div>
                      <ul className="space-y-2 text-gray-300 text-sm mb-4">
                        <li>• Web Development (Django/Flask)</li>
                        <li>• Data Science & ML</li>
                        <li>• System Administration</li>
                        <li>• API Development</li>
                      </ul>
                      <Button className="w-full bg-gradient-to-r from-pink-600 to-rose-600">Start Practice</Button>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* DSA Section */}
              <div>
                <h2 className="text-xl font-bold mb-4">Data Structures & Algorithms</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-blue-500/20 flex items-center justify-center">
                          <Code className="h-6 w-6 text-blue-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-white">Arrays & Strings</h3>
                          <Badge className="bg-green-500/20 text-green-300">Easy</Badge>
                        </div>
                      </div>
                      <ul className="space-y-2 text-gray-300 text-sm mb-4">
                        <li>• Two Pointers</li>
                        <li>• Sliding Window</li>
                        <li>• String Manipulation</li>
                        <li>• Matrix Operations</li>
                      </ul>
                      <Button className="w-full bg-gradient-to-r from-blue-600 to-cyan-600">Solve Problems</Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-amber-500/20 flex items-center justify-center">
                          <Code className="h-6 w-6 text-amber-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-white">Trees & Graphs</h3>
                          <Badge className="bg-yellow-500/20 text-yellow-300">Medium</Badge>
                        </div>
                      </div>
                      <ul className="space-y-2 text-gray-300 text-sm mb-4">
                        <li>• Binary Trees</li>
                        <li>• Graph Traversal</li>
                        <li>• Shortest Path</li>
                        <li>• Tree Balancing</li>
                      </ul>
                      <Button className="w-full bg-gradient-to-r from-amber-600 to-yellow-600">Solve Problems</Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-red-500/20 flex items-center justify-center">
                          <Code className="h-6 w-6 text-red-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-white">Dynamic Programming</h3>
                          <Badge className="bg-red-500/20 text-red-300">Hard</Badge>
                        </div>
                      </div>
                      <ul className="space-y-2 text-gray-300 text-sm mb-4">
                        <li>• Memoization</li>
                        <li>• Tabulation</li>
                        <li>• State Machines</li>
                        <li>• Optimization Problems</li>
                      </ul>
                      <Button className="w-full bg-gradient-to-r from-red-600 to-orange-600">Solve Problems</Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="career">
              {/* Career Tab Content */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-white">Career Guidance</h1>
                  <p className="text-gray-400">Expert advice to help you navigate your career path</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="relative flex-1 md:w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      type="text"
                      placeholder="Search guidance..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-gray-800/50 border-gray-700 text-gray-200 w-full"
                    />
                  </div>
                  <Button
                    variant="outline"
                    className="hidden md:flex items-center gap-2 bg-gray-800/50 border-gray-700 text-gray-200"
                  >
                    <Filter className="h-3.5 w-3.5" />
                    Filters
                  </Button>
                </div>
              </div>

              {/* Career Path Categories */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm hover:border-blue-500/50 transition-all duration-300 hover:shadow-[0_0_15px_rgba(59,130,246,0.1)]">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="h-12 w-12 rounded-full bg-blue-500/20 flex items-center justify-center">
                        <Rocket className="h-6 w-6 text-blue-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-white">Software Development</h3>
                        <p className="text-sm text-gray-400">Frontend, Backend, Full Stack</p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                    >
                      Explore Career Path
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm hover:border-green-500/50 transition-all duration-300 hover:shadow-[0_0_15px_rgba(74,222,128,0.1)]">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="h-12 w-12 rounded-full bg-green-500/20 flex items-center justify-center">
                        <Brain className="h-6 w-6 text-green-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-white">Data Science & AI</h3>
                        <p className="text-sm text-gray-400">ML, Data Analysis, Research</p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                    >
                      Explore Career Path
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm hover:border-purple-500/50 transition-all duration-300 hover:shadow-[0_0_15px_rgba(168,85,247,0.1)]">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="h-12 w-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                        <Presentation className="h-6 w-6 text-purple-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-white">Product Management</h3>
                        <p className="text-sm text-gray-400">Strategy, Development, Growth</p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                    >
                      Explore Career Path
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Career Guidance Articles */}
              <h2 className="text-xl font-bold mb-4">Career Guidance Resources</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                {filteredGuidance.slice(0, 4).map((guidance, index) => (
                  <Card key={guidance.id} className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-gray-700/50 flex items-center justify-center flex-shrink-0">
                          {guidance.category === "Interview" ? (
                            <Presentation className="h-6 w-6 text-blue-400" />
                          ) : guidance.category === "Resume" ? (
                            <FileText className="h-6 w-6 text-green-400" />
                          ) : guidance.category === "Career Path" ? (
                            <Compass className="h-6 w-6 text-purple-400" />
                          ) : (
                            <Target className="h-6 w-6 text-amber-400" />
                          )}
                        </div>
                        <div>
                          <Badge variant="outline" className="mb-2 bg-gray-700/30 border-gray-600 text-gray-300">
                            {guidance.category}
                          </Badge>
                          <h3 className="text-lg font-medium text-white mb-2">{guidance.title}</h3>
                          <p className="text-sm text-gray-400 mb-4">{guidance.description}</p>
                          <Button
                            variant="outline"
                            className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                          >
                            Read Article
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Career Planning Tools */}
              <h2 className="text-xl font-bold mb-4">Career Planning Tools</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="h-12 w-12 rounded-full bg-indigo-500/20 flex items-center justify-center mb-4">
                      <Target className="h-6 w-6 text-indigo-400" />
                    </div>
                    <h3 className="text-lg font-medium text-white mb-2">Career Assessment</h3>
                    <p className="text-sm text-gray-400 mb-4">
                      Discover your strengths, interests, and ideal career paths with our comprehensive assessment.
                    </p>
                    <Button className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500">
                      Take Assessment
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="h-12 w-12 rounded-full bg-green-500/20 flex items-center justify-center mb-4">
                      <Workflow className="h-6 w-6 text-green-400" />
                    </div>
                    <h3 className="text-lg font-medium text-white mb-2">Career Roadmap Builder</h3>
                    <p className="text-sm text-gray-400 mb-4">
                      Create a personalized career development plan with milestones and skill-building activities.
                    </p>
                    <Button className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500">
                      Build Roadmap
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="h-12 w-12 rounded-full bg-amber-500/20 flex items-center justify-center mb-4">
                      <Presentation className="h-6 w-6 text-amber-400" />
                    </div>
                    <h3 className="text-lg font-medium text-white mb-2">Mock Interviews</h3>
                    <p className="text-sm text-gray-400 mb-4">
                      Practice with AI-powered mock interviews tailored to your target roles and companies.
                    </p>
                    <Button className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500">
                      Start Practice
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="inspiration">
              {/* Inspiration Tab Content */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-white">Inspiration</h1>
                  <p className="text-gray-400">Motivational quotes and stories from tech leaders</p>
                </div>
              </div>

              {/* Tech Leaders */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {/* Elon Musk */}
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm overflow-hidden">
                  <div className="h-48 relative">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-900/90 z-10" />
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Elon%20musk.jpg-K4n3vFy2MTySj8FSf3oZW2zD2MPDg8.jpeg"
                      alt="Elon Musk"
                      width={400}
                      height={300}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6 relative">
                    <h3 className="text-xl font-bold text-white mb-2">Elon Musk</h3>
                    <p className="text-sm text-gray-400 mb-4">CEO of SpaceX, Tesla, and X</p>
                    <div className="bg-gray-700/30 rounded-lg p-4 mb-4">
                      <p className="text-white italic">
                        "When something is important enough, you do it even if the odds are not in your favor."
                      </p>
                    </div>
                    <div className="bg-gray-700/30 rounded-lg p-4">
                      <p className="text-white italic">
                        "Persistence is very important. You should not give up unless you are forced to give up."
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Bill Gates */}
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm overflow-hidden">
                  <div className="h-48 relative">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-900/90 z-10" />
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Bill%20gates.jpg-JIwpEiuy96eMnyKPxGIIbfuHBQq47v.jpeg"
                      alt="Bill Gates"
                      width={400}
                      height={300}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6 relative">
                    <h3 className="text-xl font-bold text-white mb-2">Bill Gates</h3>
                    <p className="text-sm text-gray-400 mb-4">Co-founder of Microsoft</p>
                    <div className="bg-gray-700/30 rounded-lg p-4 mb-4">
                      <p className="text-white italic">
                        "Success is a lousy teacher. It seduces smart people into thinking they can't lose."
                      </p>
                    </div>
                    <div className="bg-gray-700/30 rounded-lg p-4">
                      <p className="text-white italic">
                        "It's fine to celebrate success but it is more important to heed the lessons of failure."
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Tony Stark */}
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm overflow-hidden">
                  <div className="h-48 relative">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-900/90 z-10" />
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tony%20stark.jpg-teq6JbFvTiZgk4onR8MRa5ofDFSIPc.jpeg"
                      alt="Tony Stark"
                      width={400}
                      height={300}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6 relative">
                    <h3 className="text-xl font-bold text-white mb-2">Tony Stark</h3>
                    <p className="text-sm text-gray-400 mb-4">Genius, Billionaire, Philanthropist</p>
                    <div className="bg-gray-700/30 rounded-lg p-4 mb-4">
                      <p className="text-white italic">"Sometimes you gotta run before you can walk."</p>
                    </div>
                    <div className="bg-gray-700/30 rounded-lg p-4">
                      <p className="text-white italic">
                        "I'm a huge fan of the way you lose control and turn into an enormous green rage monster."
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* More Inspirational Quotes */}
              <h2 className="text-xl font-bold mb-4">More Inspirational Quotes</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {inspirationQuotes.slice(0, 6).map((quote, index) => (
                  <Card key={index} className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <Quote className="h-8 w-8 text-indigo-400 flex-shrink-0" />
                        <div>
                          <p className="text-white italic mb-2">"{quote.quote}"</p>
                          <p className="text-sm text-gray-400">— {quote.author}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Success Stories */}
              <h2 className="text-xl font-bold mt-8 mb-4">Success Stories</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src="/placeholder.svg?height=100&width=100" alt="Sarah Johnson" />
                        <AvatarFallback>SJ</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="text-lg font-medium text-white">Sarah Johnson</h3>
                        <p className="text-sm text-gray-400">Self-taught Developer to Senior Engineer</p>
                      </div>
                    </div>
                    <p className="text-gray-300 text-sm mb-4">
                      "I started learning to code through online courses while working a full-time job. After 8 months
                      of consistent practice and building projects, I landed my first developer role. Three years later,
                      I'm now a senior engineer at a top tech company."
                    </p>
                    <Button
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                    >
                      Read Full Story
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src="/placeholder.svg?height=100&width=100" alt="Michael Chen" />
                        <AvatarFallback>MC</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="text-lg font-medium text-white">Michael Chen</h3>
                        <p className="text-sm text-gray-400">From Bootcamp to Startup Founder</p>
                      </div>
                    </div>
                    <p className="text-gray-300 text-sm mb-4">
                      "After being laid off, I took a chance on a coding bootcamp. It was intense, but I learned so much
                      in 12 weeks. I worked at two startups before identifying a market need and launching my own
                      company. We just closed our Series A funding round!"
                    </p>
                    <Button
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                    >
                      Read Full Story
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src="/placeholder.svg?height=100&width=100" alt="Priya Sharma" />
                        <AvatarFallback>PS</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="text-lg font-medium text-white">Priya Sharma</h3>
                        <p className="text-sm text-gray-400">Career Switcher to AI Researcher</p>
                      </div>
                    </div>
                    <p className="text-gray-300 text-sm mb-4">
                      "I was a biology teacher for 7 years before deciding to pursue my interest in AI. I completed an
                      online master's in computer science while teaching, and now I'm working on cutting-edge AI
                      research at a leading lab. It's never too late to pivot!"
                    </p>
                    <Button
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                    >
                      Read Full Story
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Other tabs content remains the same */}
          </Tabs>
        </main>
      </div>

      {/* Job Application Dialog */}
      <Dialog open={!!selectedJob} onOpenChange={(open) => (open ? setSelectedJob(selectedJob) : setSelectedJob(null))}>
        <DialogContent className="bg-gray-800 border-gray-700 text-gray-100">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">{selectedJob?.title}</DialogTitle>
            <DialogDescription className="text-gray-400">
              at {selectedJob?.company} • {selectedJob?.location}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-12 w-12 bg-gray-700 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                {selectedJob?.company?.charAt(0)}
              </div>
              <div>
                <h4 className="font-medium text-white">{selectedJob?.company}</h4>
                <p className="text-sm text-gray-400">{selectedJob?.location}</p>
              </div>
            </div>

            <div className="space-y-2">
              <h5 className="font-medium text-white">Job Description</h5>
              <p className="text-gray-300 text-sm">{selectedJob?.description}</p>
            </div>

            <div className="space-y-2">
              <h5 className="font-medium text-white">Skills Required</h5>
              <div className="flex flex-wrap gap-2">
                {selectedJob?.skills?.map((skill, idx) => (
                  <Badge key={idx} variant="outline" className="bg-gray-700/50 border-gray-600 text-gray-300">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <h5 className="font-medium text-white">Salary</h5>
              <p className="text-gray-300 text-sm">{selectedJob?.salary}</p>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button variant="outline" onClick={() => setSelectedJob(null)}>
                Cancel
              </Button>
              <Button
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500"
                onClick={() => {
                  router.push(`/job/${selectedJob?.id}/apply`)
                  setSelectedJob(null)
                }}
              >
                Apply Now
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

