"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { toast } from "sonner"
import { FileText, CheckCircle2, XCircle, AlertCircle, Send, ArrowLeft, Upload, Edit, Briefcase } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useAuth } from "@/context/auth-context"
import { getJobById } from "@/lib/api"
import { getUserProfile } from "@/lib/auth"
import type { JobType } from "@/lib/types"

export default function JobApplicationPage() {
  const router = useRouter()
  const params = useParams()
  const { user } = useAuth()
  const [job, setJob] = useState<JobType | null>(null)
  const [loading, setLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [coverLetter, setCoverLetter] = useState("")
  const [userProfile, setUserProfile] = useState<any>(null)
  const [resumeFile, setResumeFile] = useState<File | null>(null)
  const [eligibilityScore, setEligibilityScore] = useState<number | null>(null)
  const [eligibilityChecks, setEligibilityChecks] = useState<any[]>([])

  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      router.push("/")
      return
    }

    const loadData = async () => {
      try {
        // Load job details
        const jobData = await getJobById(params.id as string)
        setJob(jobData)

        // Load user profile
        const profile = await getUserProfile(user.id)
        setUserProfile(profile)

        // Calculate eligibility
        calculateEligibility(jobData, profile)
      } catch (error) {
        console.error("Failed to load data:", error)
        toast.error("Failed to load job details")
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [user, router, params.id])

  const calculateEligibility = (job: JobType, profile: any) => {
    const checks = []
    let score = 0
    let totalChecks = 0

    // Check for required skills
    if (job.skills && job.skills.length > 0) {
      totalChecks++
      const userSkills = profile?.skills || []
      const matchedSkills = job.skills.filter((skill) =>
        userSkills.some(
          (userSkill: string) =>
            userSkill.toLowerCase().includes(skill.toLowerCase()) ||
            skill.toLowerCase().includes(userSkill.toLowerCase()),
        ),
      )

      const skillMatch = matchedSkills.length / job.skills.length

      if (skillMatch >= 0.7) {
        checks.push({
          name: "Skills Match",
          status: "pass",
          message: `You have ${matchedSkills.length} of ${job.skills.length} required skills`,
        })
        score++
      } else if (skillMatch >= 0.4) {
        checks.push({
          name: "Skills Match",
          status: "partial",
          message: `You have ${matchedSkills.length} of ${job.skills.length} required skills`,
        })
        score += 0.5
      } else {
        checks.push({
          name: "Skills Match",
          status: "fail",
          message: `You have only ${matchedSkills.length} of ${job.skills.length} required skills`,
        })
      }
    }

    // Check for experience
    if (profile?.experience && profile.experience.length > 0) {
      totalChecks++
      const hasExperience = profile.experience.length > 0

      if (hasExperience) {
        checks.push({
          name: "Work Experience",
          status: "pass",
          message: "You have relevant work experience",
        })
        score++
      } else {
        checks.push({
          name: "Work Experience",
          status: "fail",
          message: "No work experience found in your profile",
        })
      }
    }

    // Check for education
    if (profile?.education && profile.education.length > 0) {
      totalChecks++
      const hasEducation = profile.education.length > 0

      if (hasEducation) {
        checks.push({
          name: "Education",
          status: "pass",
          message: "You have relevant education",
        })
        score++
      } else {
        checks.push({
          name: "Education",
          status: "fail",
          message: "No education found in your profile",
        })
      }
    }

    // Check for resume
    totalChecks++
    if (profile?.resume) {
      checks.push({
        name: "Resume",
        status: "pass",
        message: "Resume is available",
      })
      score++
    } else {
      checks.push({
        name: "Resume",
        status: "fail",
        message: "No resume found in your profile",
      })
    }

    // Calculate final score
    const finalScore = Math.round((score / totalChecks) * 100)
    setEligibilityScore(finalScore)
    setEligibilityChecks(checks)
  }

  const handleResumeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (
        file.type === "application/pdf" ||
        file.type === "application/msword" ||
        file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      ) {
        setResumeFile(file)
        toast.success("Resume uploaded successfully!")
      } else {
        toast.error("Please upload a PDF or Word document")
      }
    }
  }

  const handleSubmitApplication = async () => {
    if (!coverLetter.trim()) {
      toast.error("Please add a cover letter")
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate API call to submit application
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast.success("Application submitted successfully!")
      router.push("/dashboard")
    } catch (error) {
      toast.error("Failed to submit application. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="h-12 w-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Loading job details...</p>
        </div>
      </div>
    )
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-gray-100 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-red-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">Job Not Found</h2>
          <p className="text-gray-400 mb-6">The job you're looking for doesn't exist or has been removed.</p>
          <Button
            onClick={() => router.push("/dashboard")}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500"
          >
            Back to Dashboard
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-gray-100 pb-20">
      <header className="bg-gray-800/80 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-30 p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-300 hover:text-white"
              onClick={() => router.back()}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400">
              Job Application
            </h1>
          </div>
          <Button
            variant="outline"
            className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
            onClick={() => router.push("/dashboard")}
          >
            Cancel
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 md:p-6 pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Job Details & Eligibility */}
          <div className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl font-bold">{job.title}</CardTitle>
                <CardDescription className="text-gray-400">
                  at {job.company} • {job.location}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 bg-gray-700 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                    {job.company.charAt(0)}
                  </div>
                  <div>
                    <p className="font-medium text-white">{job.company}</p>
                    <p className="text-sm text-gray-400">{job.location}</p>
                  </div>
                </div>

                <Separator className="bg-gray-700" />

                <div>
                  <h3 className="font-medium text-white mb-2">Job Description</h3>
                  <p className="text-gray-300 text-sm">{job.description}</p>
                </div>

                <div>
                  <h3 className="font-medium text-white mb-2">Required Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {job.skills?.map((skill, idx) => (
                      <Badge key={idx} variant="outline" className="bg-gray-700/50 border-gray-600 text-gray-300">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-medium text-white mb-2">Salary</h3>
                  <p className="text-gray-300 text-sm">{job.salary}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium">Eligibility Check</CardTitle>
                <CardDescription>How well you match this job's requirements</CardDescription>
              </CardHeader>
              <CardContent>
                {eligibilityScore !== null && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-300">Match Score</span>
                        <span
                          className={`text-sm font-medium ${
                            eligibilityScore >= 80
                              ? "text-green-400"
                              : eligibilityScore >= 60
                                ? "text-yellow-400"
                                : "text-orange-400"
                          }`}
                        >
                          {eligibilityScore}%
                        </span>
                      </div>
                      <Progress
                        value={eligibilityScore}
                        className="h-2 bg-gray-700"
                        indicatorClassName={`${
                          eligibilityScore >= 80
                            ? "bg-green-500"
                            : eligibilityScore >= 60
                              ? "bg-yellow-500"
                              : "bg-orange-500"
                        }`}
                      />
                    </div>

                    <div className="space-y-3 mt-4">
                      {eligibilityChecks.map((check, index) => (
                        <div
                          key={index}
                          className={`flex items-start gap-2 p-3 rounded-md ${
                            check.status === "pass"
                              ? "bg-green-500/10"
                              : check.status === "partial"
                                ? "bg-yellow-500/10"
                                : "bg-red-500/10"
                          }`}
                        >
                          {check.status === "pass" ? (
                            <CheckCircle2 className="h-5 w-5 text-green-400 mt-0.5" />
                          ) : check.status === "partial" ? (
                            <AlertCircle className="h-5 w-5 text-yellow-400 mt-0.5" />
                          ) : (
                            <XCircle className="h-5 w-5 text-red-400 mt-0.5" />
                          )}
                          <div>
                            <p className="font-medium text-white">{check.name}</p>
                            <p className="text-sm text-gray-300">{check.message}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {eligibilityScore < 60 && (
                      <Alert className="bg-orange-500/10 border-orange-500/30 text-orange-300 mt-4">
                        <AlertTitle className="flex items-center">
                          <AlertCircle className="h-4 w-4 mr-2" />
                          Low Match Score
                        </AlertTitle>
                        <AlertDescription className="text-gray-300 mt-2">
                          Your profile doesn't match many of the job requirements. Consider updating your profile or
                          looking for jobs that better match your skills.
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Application Form */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium">Your Application</CardTitle>
                <CardDescription>Complete the form below to apply for this position</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Resume Section */}
                <div>
                  <h3 className="font-medium text-white mb-4">Resume</h3>

                  {userProfile?.resume || resumeFile ? (
                    <div className="bg-gray-700/30 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 bg-indigo-500/20 rounded-full flex items-center justify-center">
                            <FileText className="h-5 w-5 text-indigo-400" />
                          </div>
                          <div>
                            <p className="font-medium text-white">{resumeFile ? resumeFile.name : "Your Resume.pdf"}</p>
                            <p className="text-sm text-gray-400">
                              {resumeFile
                                ? `${(resumeFile.size / 1024 / 1024).toFixed(2)} MB`
                                : "Last updated: 2 weeks ago"}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white">
                            <label className="cursor-pointer flex items-center gap-1">
                              <Edit className="h-4 w-4" />
                              <span>Replace</span>
                              <input
                                type="file"
                                className="hidden"
                                accept=".pdf,.doc,.docx"
                                onChange={handleResumeUpload}
                              />
                            </label>
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-gray-700 rounded-lg p-6 text-center">
                      <label className="cursor-pointer block space-y-4">
                        <div className="h-12 w-12 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto">
                          <Upload className="h-6 w-6 text-gray-400" />
                        </div>
                        <div>
                          <p className="text-white font-medium">Upload your resume</p>
                          <p className="text-sm text-gray-400">PDF or Word document, max 5MB</p>
                        </div>
                        <Button
                          variant="outline"
                          className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                        >
                          Browse Files
                        </Button>
                        <input type="file" className="hidden" accept=".pdf,.doc,.docx" onChange={handleResumeUpload} />
                      </label>
                    </div>
                  )}
                </div>

                {/* Cover Letter */}
                <div>
                  <h3 className="font-medium text-white mb-4">Cover Letter</h3>
                  <Textarea
                    value={coverLetter}
                    onChange={(e) => setCoverLetter(e.target.value)}
                    className="bg-gray-800/50 border-gray-700 text-gray-200 min-h-[200px]"
                    placeholder="Explain why you're a good fit for this position and what makes you interested in this role..."
                  />
                </div>

                {/* Additional Questions */}
                <div>
                  <h3 className="font-medium text-white mb-4">Additional Questions</h3>

                  <div className="space-y-4">
                    <div>
                      <p className="text-gray-300 mb-2">
                        Are you authorized to work in the country where this job is located?
                      </p>
                      <div className="flex gap-4">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="authorized" className="accent-indigo-500" />
                          <span className="text-gray-300">Yes</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="authorized" className="accent-indigo-500" />
                          <span className="text-gray-300">No</span>
                        </label>
                      </div>
                    </div>

                    <div>
                      <p className="text-gray-300 mb-2">How many years of relevant experience do you have?</p>
                      <div className="flex gap-4">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="experience" className="accent-indigo-500" />
                          <span className="text-gray-300">0-1 years</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="experience" className="accent-indigo-500" />
                          <span className="text-gray-300">1-3 years</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="experience" className="accent-indigo-500" />
                          <span className="text-gray-300">3+ years</span>
                        </label>
                      </div>
                    </div>

                    <div>
                      <p className="text-gray-300 mb-2">When can you start?</p>
                      <div className="flex gap-4">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="start" className="accent-indigo-500" />
                          <span className="text-gray-300">Immediately</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="start" className="accent-indigo-500" />
                          <span className="text-gray-300">1-2 weeks</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="start" className="accent-indigo-500" />
                          <span className="text-gray-300">More than 2 weeks</span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500"
                  onClick={handleSubmitApplication}
                  disabled={isSubmitting || !coverLetter.trim() || (!userProfile?.resume && !resumeFile)}
                >
                  {isSubmitting ? (
                    <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Submit Application
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium">Resume Builder</CardTitle>
                <CardDescription>Create or update your resume</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-300">
                  Need help creating a professional resume? Use our resume builder to create a tailored resume for this
                  job.
                </p>
                <Button
                  variant="outline"
                  className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                  onClick={() => router.push("/resume-builder")}
                >
                  <Briefcase className="h-4 w-4 mr-2" />
                  Open Resume Builder
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

