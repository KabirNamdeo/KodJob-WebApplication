"use client"

import type React from "react"

import { useRouter } from "next/navigation"
import { useState } from "react"
import { motion } from "framer-motion"
import { toast } from "sonner"
import { LucideLogIn, Eye, EyeOff, UserPlus } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/context/auth-context"
import { registerUser } from "@/lib/auth"

export default function AuthPage() {
  const router = useRouter()
  const { login } = useAuth()
  const [activeTab, setActiveTab] = useState("login")

  // Login state
  const [loginData, setLoginData] = useState({
    username: "",
    password: "",
    showPassword: false,
  })
  const [isLoginLoading, setIsLoginLoading] = useState(false)

  // Signup state
  const [signupData, setSignupData] = useState({
    name: "",
    username: "",
    password: "",
    confirmPassword: "",
    showPassword: false,
  })
  const [isSignupLoading, setIsSignupLoading] = useState(false)

  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setLoginData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSignupChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setSignupData((prev) => ({ ...prev, [name]: value }))
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoginLoading(true)

    try {
      const success = await login(loginData.username, loginData.password)

      if (success) {
        toast.success("Login successful!")
        router.push("/dashboard")
      } else {
        toast.error("Invalid username or password")
      }
    } catch (error) {
      toast.error("An error occurred during login")
    } finally {
      setIsLoginLoading(false)
    }
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()

    if (signupData.password !== signupData.confirmPassword) {
      toast.error("Passwords do not match")
      return
    }

    if (signupData.password.length < 6) {
      toast.error("Password must be at least 6 characters")
      return
    }

    setIsSignupLoading(true)

    try {
      const success = await registerUser(signupData.username, signupData.password, signupData.name)

      if (success) {
        toast.success("Account created successfully!")
        setActiveTab("login")
        setLoginData({
          ...loginData,
          username: signupData.username,
        })
      } else {
        toast.error("Username already exists")
      }
    } catch (error) {
      toast.error("An error occurred during registration")
    } finally {
      setIsSignupLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left Side - Visual Content */}
      <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-indigo-600 to-purple-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,255,255,0.1),rgba(0,0,0,0.1))]" />

        <div className="relative z-10 flex flex-col justify-center px-12 py-8 h-full">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="text-4xl font-bold mb-6">KodJob</h1>
            <p className="text-xl font-medium mb-4">Find Your Dream Job</p>
            <p className="text-white/80 mb-8 max-w-md">
              Connect with top employers, discover exciting opportunities, and take the next step in your career
              journey.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-3">
                <div className="mt-1 bg-white/20 p-2 rounded-full">
                  <CheckIcon className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="font-medium">Personalized Job Recommendations</h3>
                  <p className="text-white/70 text-sm">Get job suggestions tailored to your skills and experience</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="mt-1 bg-white/20 p-2 rounded-full">
                  <CheckIcon className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="font-medium">Application Tracking</h3>
                  <p className="text-white/70 text-sm">Monitor your applications and interview status in one place</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="mt-1 bg-white/20 p-2 rounded-full">
                  <CheckIcon className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="font-medium">Career Resources</h3>
                  <p className="text-white/70 text-sm">Access tools and tips to help you succeed in your job search</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="absolute bottom-4 left-12 text-white/60 text-sm">© 2023 KodJob. All rights reserved.</div>
      </div>

      {/* Right Side - Auth Forms */}
      <div className="flex-1 flex items-center justify-center p-6 bg-gradient-to-br from-gray-900 to-gray-800 md:w-1/2">
        <div className="w-full max-w-md">
          <div className="text-center mb-8 md:hidden">
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400 mb-2">
              KodJob
            </h1>
            <p className="text-gray-400">Find your dream job</p>
          </div>

          {activeTab === "login" ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="w-full"
            >
              <div className="relative backdrop-blur-sm bg-black/30 rounded-2xl border border-gray-700 shadow-[0_0_15px_rgba(125,125,255,0.07)] p-8">
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 rounded-2xl -z-10" />

                <div className="flex justify-center mb-6">
                  <div className="grid grid-cols-2 gap-1 bg-gray-800/70 p-1 rounded-lg">
                    <button
                      onClick={() => setActiveTab("login")}
                      className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                        activeTab === "login" ? "bg-white text-gray-900" : "text-gray-300 hover:text-white"
                      }`}
                    >
                      Login
                    </button>
                    <button
                      onClick={() => setActiveTab("signup")}
                      className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                        activeTab === "signup" ? "bg-white text-gray-900" : "text-gray-300 hover:text-white"
                      }`}
                    >
                      Sign Up
                    </button>
                  </div>
                </div>

                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-white mb-2">Welcome Back</h2>
                  <p className="text-gray-400">Sign in to access your account</p>
                </div>

                <form onSubmit={handleLogin} className="space-y-6">
                  <div>
                    <Label htmlFor="username" className="text-gray-300 mb-2 block">
                      Username
                    </Label>
                    <Input
                      id="username"
                      name="username"
                      type="text"
                      value={loginData.username}
                      onChange={handleLoginChange}
                      required
                      className="bg-gray-800/50 border-gray-700 text-gray-200 focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="Enter your username"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <Label htmlFor="password" className="text-gray-300">
                        Password
                      </Label>
                      <Link
                        href="/forgot-password"
                        className="text-sm text-indigo-400 hover:text-indigo-300 hover:underline"
                      >
                        Forgot password?
                      </Link>
                    </div>
                    <div className="relative">
                      <Input
                        id="password"
                        name="password"
                        type={loginData.showPassword ? "text" : "password"}
                        value={loginData.password}
                        onChange={handleLoginChange}
                        required
                        className="bg-gray-800/50 border-gray-700 text-gray-200 focus:ring-indigo-500 focus:border-indigo-500 pr-10"
                        placeholder="Enter your password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 text-gray-400 hover:text-gray-300"
                        onClick={() => setLoginData((prev) => ({ ...prev, showPassword: !prev.showPassword }))}
                      >
                        {loginData.showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-medium py-2 px-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2"
                    disabled={isLoginLoading}
                  >
                    {isLoginLoading ? (
                      <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <LucideLogIn className="h-4 w-4" />
                        Sign In
                      </>
                    )}
                  </Button>
                </form>

                <div className="mt-6 text-center text-sm text-gray-400">
                  Don&apos;t have an account?{" "}
                  <button
                    onClick={() => setActiveTab("signup")}
                    className="text-indigo-400 hover:text-indigo-300 hover:underline"
                  >
                    Sign up
                  </button>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="w-full"
            >
              <div className="relative backdrop-blur-sm bg-black/30 rounded-2xl border border-gray-700 shadow-[0_0_15px_rgba(125,125,255,0.07)] p-8">
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 rounded-2xl -z-10" />

                <div className="flex justify-center mb-6">
                  <div className="grid grid-cols-2 gap-1 bg-gray-800/70 p-1 rounded-lg">
                    <button
                      onClick={() => setActiveTab("login")}
                      className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                        activeTab === "login" ? "bg-white text-gray-900" : "text-gray-300 hover:text-white"
                      }`}
                    >
                      Login
                    </button>
                    <button
                      onClick={() => setActiveTab("signup")}
                      className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                        activeTab === "signup" ? "bg-white text-gray-900" : "text-gray-300 hover:text-white"
                      }`}
                    >
                      Sign Up
                    </button>
                  </div>
                </div>

                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-white mb-2">Create Account</h2>
                  <p className="text-gray-400">Join KodJob to find your dream job</p>
                </div>

                <form onSubmit={handleSignup} className="space-y-4">
                  <div>
                    <Label htmlFor="name" className="text-gray-300 mb-2 block">
                      Full Name
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      value={signupData.name}
                      onChange={handleSignupChange}
                      required
                      className="bg-gray-800/50 border-gray-700 text-gray-200 focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <Label htmlFor="signup-username" className="text-gray-300 mb-2 block">
                      Username
                    </Label>
                    <Input
                      id="signup-username"
                      name="username"
                      type="text"
                      value={signupData.username}
                      onChange={handleSignupChange}
                      required
                      className="bg-gray-800/50 border-gray-700 text-gray-200 focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="Choose a username"
                    />
                  </div>

                  <div>
                    <Label htmlFor="signup-password" className="text-gray-300 mb-2 block">
                      Password
                    </Label>
                    <div className="relative">
                      <Input
                        id="signup-password"
                        name="password"
                        type={signupData.showPassword ? "text" : "password"}
                        value={signupData.password}
                        onChange={handleSignupChange}
                        required
                        className="bg-gray-800/50 border-gray-700 text-gray-200 focus:ring-indigo-500 focus:border-indigo-500 pr-10"
                        placeholder="Create a password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 text-gray-400 hover:text-gray-300"
                        onClick={() => setSignupData((prev) => ({ ...prev, showPassword: !prev.showPassword }))}
                      >
                        {signupData.showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword" className="text-gray-300 mb-2 block">
                      Confirm Password
                    </Label>
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={signupData.confirmPassword}
                      onChange={handleSignupChange}
                      required
                      className="bg-gray-800/50 border-gray-700 text-gray-200 focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="Confirm your password"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-medium py-2 px-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 mt-6"
                    disabled={isSignupLoading}
                  >
                    {isSignupLoading ? (
                      <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4" />
                        Create Account
                      </>
                    )}
                  </Button>
                </form>

                <div className="mt-6 text-center text-sm text-gray-400">
                  Already have an account?{" "}
                  <button
                    onClick={() => setActiveTab("login")}
                    className="text-indigo-400 hover:text-indigo-300 hover:underline"
                  >
                    Sign in
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}

// Simple check icon component
function CheckIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="3"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  )
}

