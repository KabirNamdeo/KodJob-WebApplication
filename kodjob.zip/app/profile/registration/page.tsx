"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import {
  Upload,
  FileText,
  User,
  Mail,
  Phone,
  MapPin,
  Globe,
  Briefcase,
  GraduationCap,
  Languages,
  Award,
  Save,
  AlertCircle,
  CheckCircle2,
  X,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useAuth } from "@/context/auth-context"
import { updateUserProfile } from "@/lib/auth"

export default function RegistrationPage() {
  const router = useRouter()
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("personal")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [resumeFile, setResumeFile] = useState<File | null>(null)
  const [atsScore, setAtsScore] = useState<number | null>(null)
  const [profileCompletion, setProfileCompletion] = useState(0)
  const [showATSFeedback, setShowATSFeedback] = useState(false)

  // Form state
  const [formData, setFormData] = useState({
    // Personal Information
    fullName: user?.name || "",
    email: user?.email || "",
    phone: "",
    location: "",
    website: "",
    bio: "",

    // Education
    education: [
      {
        degree: "",
        institution: "",
        fieldOfStudy: "",
        startDate: "",
        endDate: "",
        description: "",
      },
    ],

    // Experience
    experience: [
      {
        title: "",
        company: "",
        location: "",
        startDate: "",
        endDate: "",
        current: false,
        description: "",
      },
    ],

    // Skills
    skills: [""],

    // Languages
    languages: [{ language: "", proficiency: "" }],

    // Certifications
    certifications: [{ name: "", issuer: "", date: "", expires: "", description: "" }],
  })

  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      router.push("/")
    }
  }, [user, router])

  // Calculate profile completion percentage
  useEffect(() => {
    let completedFields = 0
    let totalFields = 0

    // Personal info
    const personalFields = ["fullName", "email", "phone", "location", "bio"]
    personalFields.forEach((field) => {
      totalFields++
      if (
        formData[field as keyof typeof formData] &&
        typeof formData[field as keyof typeof formData] === "string" &&
        (formData[field as keyof typeof formData] as string).trim() !== ""
      ) {
        completedFields++
      }
    })

    // Education
    if (formData.education.length > 0 && formData.education[0].degree && formData.education[0].institution) {
      completedFields += 2
    }
    totalFields += 2

    // Experience
    if (formData.experience.length > 0 && formData.experience[0].title && formData.experience[0].company) {
      completedFields += 2
    }
    totalFields += 2

    // Skills
    if (formData.skills.length > 0 && formData.skills[0]) {
      completedFields++
    }
    totalFields++

    // Resume
    if (resumeFile) {
      completedFields++
    }
    totalFields++

    const percentage = Math.round((completedFields / totalFields) * 100)
    setProfileCompletion(percentage)
  }, [formData, resumeFile])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleArrayInputChange = (
    arrayName: "education" | "experience" | "skills" | "languages" | "certifications",
    index: number,
    field: string,
    value: string | boolean,
  ) => {
    setFormData((prev) => {
      const newArray = [...prev[arrayName]]
      newArray[index] = {
        ...newArray[index],
        [field]: value,
      }
      return {
        ...prev,
        [arrayName]: newArray,
      }
    })
  }

  const addArrayItem = (arrayName: "education" | "experience" | "skills" | "languages" | "certifications") => {
    setFormData((prev) => {
      let newItem

      switch (arrayName) {
        case "education":
          newItem = { degree: "", institution: "", fieldOfStudy: "", startDate: "", endDate: "", description: "" }
          break
        case "experience":
          newItem = {
            title: "",
            company: "",
            location: "",
            startDate: "",
            endDate: "",
            current: false,
            description: "",
          }
          break
        case "skills":
          newItem = ""
          break
        case "languages":
          newItem = { language: "", proficiency: "" }
          break
        case "certifications":
          newItem = { name: "", issuer: "", date: "", expires: "", description: "" }
          break
        default:
          newItem = {}
      }

      return {
        ...prev,
        [arrayName]: [...prev[arrayName], newItem],
      }
    })
  }

  const removeArrayItem = (
    arrayName: "education" | "experience" | "skills" | "languages" | "certifications",
    index: number,
  ) => {
    setFormData((prev) => {
      const newArray = [...prev[arrayName]]
      newArray.splice(index, 1)

      // Don't allow empty arrays for skills
      if (arrayName === "skills" && newArray.length === 0) {
        newArray.push("")
      }

      return {
        ...prev,
        [arrayName]: newArray,
      }
    })
  }

  const handleResumeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (
        file.type === "application/pdf" ||
        file.type === "application/msword" ||
        file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      ) {
        setResumeFile(file)

        // Simulate ATS scoring
        setTimeout(() => {
          const score = Math.floor(Math.random() * 41) + 60 // Random score between 60-100
          setAtsScore(score)
          setShowATSFeedback(true)
        }, 1500)

        toast.success("Resume uploaded successfully!")
      } else {
        toast.error("Please upload a PDF or Word document")
      }
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Simulate API call to update profile
      await updateUserProfile(user?.id || "", formData)

      toast.success("Profile updated successfully!")
      router.push("/dashboard")
    } catch (error) {
      toast.error("Failed to update profile. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const getATSFeedback = () => {
    if (!atsScore) return []

    if (atsScore >= 90) {
      return [
        { type: "positive", message: "Strong keyword matching with job descriptions" },
        { type: "positive", message: "Clear section headings detected" },
        { type: "positive", message: "Good use of action verbs" },
        { type: "positive", message: "Proper formatting for ATS scanning" },
      ]
    } else if (atsScore >= 75) {
      return [
        { type: "positive", message: "Good keyword matching with job descriptions" },
        { type: "positive", message: "Clear section headings detected" },
        { type: "warning", message: "Consider adding more industry-specific keywords" },
        { type: "warning", message: "Quantify achievements with more metrics" },
      ]
    } else {
      return [
        { type: "warning", message: "Limited keyword matching with job descriptions" },
        { type: "warning", message: "Add more relevant skills to improve matching" },
        { type: "warning", message: "Use standard section headings for better parsing" },
        { type: "warning", message: "Avoid complex formatting and tables" },
      ]
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-gray-100 pb-20">
      <header className="bg-gray-800/80 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-30 p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400">
            KodJob
          </h1>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
              onClick={() => router.push("/dashboard")}
            >
              Cancel
            </Button>
            <Button
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500"
              onClick={handleSubmit}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Profile
                </>
              )}
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 md:p-6 pt-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white mb-2">Complete Your Profile</h1>
          <p className="text-gray-400">Fill in your details to help employers find you and improve your job matches</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Profile Completion & Resume */}
          <div className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium">Profile Completion</CardTitle>
                <CardDescription>Complete your profile to improve job matches</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-300">Completion</span>
                    <span className="text-sm font-medium text-indigo-400">{profileCompletion}%</span>
                  </div>
                  <Progress
                    value={profileCompletion}
                    className="h-2 bg-gray-700"
                    indicatorClassName={`bg-gradient-to-r ${
                      profileCompletion < 50
                        ? "from-red-500 to-orange-500"
                        : profileCompletion < 80
                          ? "from-orange-500 to-yellow-500"
                          : "from-green-500 to-emerald-500"
                    }`}
                  />
                </div>

                <div className="mt-6 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Personal Information</span>
                    <Badge
                      variant="outline"
                      className={
                        formData.fullName && formData.email && formData.phone
                          ? "bg-green-500/20 text-green-300 border-green-500/30"
                          : "bg-gray-700/30 text-gray-400 border-gray-600/30"
                      }
                    >
                      {formData.fullName && formData.email && formData.phone ? "Complete" : "Incomplete"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Education</span>
                    <Badge
                      variant="outline"
                      className={
                        formData.education[0].degree && formData.education[0].institution
                          ? "bg-green-500/20 text-green-300 border-green-500/30"
                          : "bg-gray-700/30 text-gray-400 border-gray-600/30"
                      }
                    >
                      {formData.education[0].degree && formData.education[0].institution ? "Complete" : "Incomplete"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Experience</span>
                    <Badge
                      variant="outline"
                      className={
                        formData.experience[0].title && formData.experience[0].company
                          ? "bg-green-500/20 text-green-300 border-green-500/30"
                          : "bg-gray-700/30 text-gray-400 border-gray-600/30"
                      }
                    >
                      {formData.experience[0].title && formData.experience[0].company ? "Complete" : "Incomplete"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Skills</span>
                    <Badge
                      variant="outline"
                      className={
                        formData.skills[0]
                          ? "bg-green-500/20 text-green-300 border-green-500/30"
                          : "bg-gray-700/30 text-gray-400 border-gray-600/30"
                      }
                    >
                      {formData.skills[0] ? "Complete" : "Incomplete"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Resume</span>
                    <Badge
                      variant="outline"
                      className={
                        resumeFile
                          ? "bg-green-500/20 text-green-300 border-green-500/30"
                          : "bg-gray-700/30 text-gray-400 border-gray-600/30"
                      }
                    >
                      {resumeFile ? "Uploaded" : "Not Uploaded"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium">Resume</CardTitle>
                <CardDescription>Upload your resume for job applications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border-2 border-dashed border-gray-700 rounded-lg p-6 text-center">
                  {resumeFile ? (
                    <div className="space-y-4">
                      <div className="h-12 w-12 bg-indigo-500/20 rounded-full flex items-center justify-center mx-auto">
                        <FileText className="h-6 w-6 text-indigo-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">{resumeFile.name}</p>
                        <p className="text-sm text-gray-400">{(resumeFile.size / 1024 / 1024).toFixed(2)} MB</p>
                      </div>
                      <Button
                        variant="outline"
                        className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                        onClick={() => setResumeFile(null)}
                      >
                        Replace
                      </Button>
                    </div>
                  ) : (
                    <label className="cursor-pointer block space-y-4">
                      <div className="h-12 w-12 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto">
                        <Upload className="h-6 w-6 text-gray-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">Upload your resume</p>
                        <p className="text-sm text-gray-400">PDF or Word document, max 5MB</p>
                      </div>
                      <Button
                        variant="outline"
                        className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                      >
                        Browse Files
                      </Button>
                      <input type="file" className="hidden" accept=".pdf,.doc,.docx" onChange={handleResumeUpload} />
                    </label>
                  )}
                </div>

                {/* ATS Score */}
                {atsScore !== null && (
                  <div className="mt-6 space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-300">ATS Compatibility Score</span>
                      <span
                        className={`text-sm font-medium ${
                          atsScore >= 90 ? "text-green-400" : atsScore >= 75 ? "text-yellow-400" : "text-orange-400"
                        }`}
                      >
                        {atsScore}%
                      </span>
                    </div>
                    <Progress
                      value={atsScore}
                      className="h-2 bg-gray-700"
                      indicatorClassName={`${
                        atsScore >= 90 ? "bg-green-500" : atsScore >= 75 ? "bg-yellow-500" : "bg-orange-500"
                      }`}
                    />

                    <Button
                      variant="ghost"
                      className="w-full text-indigo-400 hover:text-indigo-300 hover:bg-gray-700/50 mt-2"
                      onClick={() => setShowATSFeedback(!showATSFeedback)}
                    >
                      {showATSFeedback ? "Hide Feedback" : "View ATS Feedback"}
                    </Button>

                    {showATSFeedback && (
                      <div className="space-y-2 mt-2">
                        {getATSFeedback().map((feedback, index) => (
                          <div
                            key={index}
                            className={`flex items-start gap-2 p-2 rounded-md ${
                              feedback.type === "positive" ? "bg-green-500/10" : "bg-orange-500/10"
                            }`}
                          >
                            {feedback.type === "positive" ? (
                              <CheckCircle2 className="h-4 w-4 text-green-400 mt-0.5" />
                            ) : (
                              <AlertCircle className="h-4 w-4 text-orange-400 mt-0.5" />
                            )}
                            <span className="text-sm text-gray-300">{feedback.message}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Profile Form */}
          <div className="lg:col-span-2">
            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid grid-cols-3 md:grid-cols-6">
                    <TabsTrigger value="personal">Personal</TabsTrigger>
                    <TabsTrigger value="education">Education</TabsTrigger>
                    <TabsTrigger value="experience">Experience</TabsTrigger>
                    <TabsTrigger value="skills">Skills</TabsTrigger>
                    <TabsTrigger value="languages">Languages</TabsTrigger>
                    <TabsTrigger value="certifications">Certifications</TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={handleSubmit}>
                  {/* Personal Information */}
                  <TabsContent value="personal" className="mt-0 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="fullName" className="text-gray-300 mb-2 block">
                          Full Name <span className="text-red-400">*</span>
                        </Label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                          <Input
                            id="fullName"
                            name="fullName"
                            value={formData.fullName}
                            onChange={handleInputChange}
                            required
                            className="bg-gray-800/50 border-gray-700 text-gray-200 pl-10"
                            placeholder="John Doe"
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="email" className="text-gray-300 mb-2 block">
                          Email <span className="text-red-400">*</span>
                        </Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            required
                            className="bg-gray-800/50 border-gray-700 text-gray-200 pl-10"
                            placeholder="john.doe@example.com"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="phone" className="text-gray-300 mb-2 block">
                          Phone Number <span className="text-red-400">*</span>
                        </Label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                          <Input
                            id="phone"
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            required
                            className="bg-gray-800/50 border-gray-700 text-gray-200 pl-10"
                            placeholder="+1 (555) 123-4567"
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="location" className="text-gray-300 mb-2 block">
                          Location <span className="text-red-400">*</span>
                        </Label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                          <Input
                            id="location"
                            name="location"
                            value={formData.location}
                            onChange={handleInputChange}
                            required
                            className="bg-gray-800/50 border-gray-700 text-gray-200 pl-10"
                            placeholder="New York, NY"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="website" className="text-gray-300 mb-2 block">
                        Website/Portfolio
                      </Label>
                      <div className="relative">
                        <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                        <Input
                          id="website"
                          name="website"
                          value={formData.website}
                          onChange={handleInputChange}
                          className="bg-gray-800/50 border-gray-700 text-gray-200 pl-10"
                          placeholder="https://yourportfolio.com"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="bio" className="text-gray-300 mb-2 block">
                        Professional Summary
                      </Label>
                      <Textarea
                        id="bio"
                        name="bio"
                        value={formData.bio}
                        onChange={handleInputChange}
                        className="bg-gray-800/50 border-gray-700 text-gray-200 min-h-[120px]"
                        placeholder="Write a brief summary of your professional background, skills, and career goals..."
                      />
                    </div>
                  </TabsContent>

                  {/* Education */}
                  <TabsContent value="education" className="mt-0 space-y-6">
                    {formData.education.map((edu, index) => (
                      <div key={index} className="space-y-4">
                        {index > 0 && <Separator className="bg-gray-700 my-6" />}

                        <div className="flex justify-between items-center">
                          <h3 className="text-white font-medium">Education #{index + 1}</h3>
                          {index > 0 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                              onClick={() => removeArrayItem("education", index)}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Remove
                            </Button>
                          )}
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor={`degree-${index}`} className="text-gray-300 mb-2 block">
                              Degree/Certificate <span className="text-red-400">*</span>
                            </Label>
                            <Input
                              id={`degree-${index}`}
                              value={edu.degree}
                              onChange={(e) => handleArrayInputChange("education", index, "degree", e.target.value)}
                              required
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                              placeholder="Bachelor of Science"
                            />
                          </div>
                          <div>
                            <Label htmlFor={`institution-${index}`} className="text-gray-300 mb-2 block">
                              Institution <span className="text-red-400">*</span>
                            </Label>
                            <Input
                              id={`institution-${index}`}
                              value={edu.institution}
                              onChange={(e) =>
                                handleArrayInputChange("education", index, "institution", e.target.value)
                              }
                              required
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                              placeholder="University of Example"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor={`fieldOfStudy-${index}`} className="text-gray-300 mb-2 block">
                              Field of Study
                            </Label>
                            <Input
                              id={`fieldOfStudy-${index}`}
                              value={edu.fieldOfStudy}
                              onChange={(e) =>
                                handleArrayInputChange("education", index, "fieldOfStudy", e.target.value)
                              }
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                              placeholder="Computer Science"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <Label htmlFor={`startDate-${index}`} className="text-gray-300 mb-2 block">
                                Start Date
                              </Label>
                              <Input
                                id={`startDate-${index}`}
                                type="month"
                                value={edu.startDate}
                                onChange={(e) =>
                                  handleArrayInputChange("education", index, "startDate", e.target.value)
                                }
                                className="bg-gray-800/50 border-gray-700 text-gray-200"
                              />
                            </div>
                            <div>
                              <Label htmlFor={`endDate-${index}`} className="text-gray-300 mb-2 block">
                                End Date
                              </Label>
                              <Input
                                id={`endDate-${index}`}
                                type="month"
                                value={edu.endDate}
                                onChange={(e) => handleArrayInputChange("education", index, "endDate", e.target.value)}
                                className="bg-gray-800/50 border-gray-700 text-gray-200"
                              />
                            </div>
                          </div>
                        </div>

                        <div>
                          <Label htmlFor={`description-${index}`} className="text-gray-300 mb-2 block">
                            Description
                          </Label>
                          <Textarea
                            id={`description-${index}`}
                            value={edu.description}
                            onChange={(e) => handleArrayInputChange("education", index, "description", e.target.value)}
                            className="bg-gray-800/50 border-gray-700 text-gray-200"
                            placeholder="Describe your studies, achievements, or relevant coursework..."
                          />
                        </div>
                      </div>
                    ))}

                    <Button
                      type="button"
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                      onClick={() => addArrayItem("education")}
                    >
                      <GraduationCap className="h-4 w-4 mr-2" />
                      Add Another Education
                    </Button>
                  </TabsContent>

                  {/* Experience */}
                  <TabsContent value="experience" className="mt-0 space-y-6">
                    {formData.experience.map((exp, index) => (
                      <div key={index} className="space-y-4">
                        {index > 0 && <Separator className="bg-gray-700 my-6" />}

                        <div className="flex justify-between items-center">
                          <h3 className="text-white font-medium">Experience #{index + 1}</h3>
                          {index > 0 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                              onClick={() => removeArrayItem("experience", index)}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Remove
                            </Button>
                          )}
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor={`title-${index}`} className="text-gray-300 mb-2 block">
                              Job Title <span className="text-red-400">*</span>
                            </Label>
                            <Input
                              id={`title-${index}`}
                              value={exp.title}
                              onChange={(e) => handleArrayInputChange("experience", index, "title", e.target.value)}
                              required
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                              placeholder="Software Engineer"
                            />
                          </div>
                          <div>
                            <Label htmlFor={`company-${index}`} className="text-gray-300 mb-2 block">
                              Company <span className="text-red-400">*</span>
                            </Label>
                            <Input
                              id={`company-${index}`}
                              value={exp.company}
                              onChange={(e) => handleArrayInputChange("experience", index, "company", e.target.value)}
                              required
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                              placeholder="Example Corp"
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor={`location-${index}`} className="text-gray-300 mb-2 block">
                            Location
                          </Label>
                          <Input
                            id={`location-${index}`}
                            value={exp.location}
                            onChange={(e) => handleArrayInputChange("experience", index, "location", e.target.value)}
                            className="bg-gray-800/50 border-gray-700 text-gray-200"
                            placeholder="New York, NY"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor={`expStartDate-${index}`} className="text-gray-300 mb-2 block">
                              Start Date
                            </Label>
                            <Input
                              id={`expStartDate-${index}`}
                              type="month"
                              value={exp.startDate}
                              onChange={(e) => handleArrayInputChange("experience", index, "startDate", e.target.value)}
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                            />
                          </div>
                          <div>
                            <Label htmlFor={`expEndDate-${index}`} className="text-gray-300 mb-2 block">
                              End Date
                            </Label>
                            <Input
                              id={`expEndDate-${index}`}
                              type="month"
                              value={exp.endDate}
                              onChange={(e) => handleArrayInputChange("experience", index, "endDate", e.target.value)}
                              disabled={exp.current}
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                            />
                            <div className="flex items-center mt-2">
                              <input
                                type="checkbox"
                                id={`current-${index}`}
                                checked={exp.current}
                                onChange={(e) =>
                                  handleArrayInputChange("experience", index, "current", e.target.checked)
                                }
                                className="mr-2"
                              />
                              <Label htmlFor={`current-${index}`} className="text-gray-300 text-sm">
                                I currently work here
                              </Label>
                            </div>
                          </div>
                        </div>

                        <div>
                          <Label htmlFor={`expDescription-${index}`} className="text-gray-300 mb-2 block">
                            Description
                          </Label>
                          <Textarea
                            id={`expDescription-${index}`}
                            value={exp.description}
                            onChange={(e) => handleArrayInputChange("experience", index, "description", e.target.value)}
                            className="bg-gray-800/50 border-gray-700 text-gray-200 min-h-[120px]"
                            placeholder="Describe your responsibilities, achievements, and the technologies you worked with..."
                          />
                        </div>
                      </div>
                    ))}

                    <Button
                      type="button"
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                      onClick={() => addArrayItem("experience")}
                    >
                      <Briefcase className="h-4 w-4 mr-2" />
                      Add Another Experience
                    </Button>
                  </TabsContent>

                  {/* Skills */}
                  <TabsContent value="skills" className="mt-0 space-y-6">
                    <Alert className="bg-indigo-500/10 border-indigo-500/30 text-indigo-300">
                      <AlertTitle className="flex items-center">
                        <AlertCircle className="h-4 w-4 mr-2" />
                        Pro Tip
                      </AlertTitle>
                      <AlertDescription className="text-gray-300 mt-2">
                        Add skills that match job descriptions to improve your ATS score and visibility to employers.
                      </AlertDescription>
                    </Alert>

                    <div className="space-y-4">
                      <Label className="text-gray-300 block">
                        Skills <span className="text-red-400">*</span>
                      </Label>

                      {formData.skills.map((skill, index) => (
                        <div key={index} className="flex gap-2">
                          <Input
                            value={skill}
                            onChange={(e) => handleArrayInputChange("skills", index, "0", e.target.value)}
                            className="bg-gray-800/50 border-gray-700 text-gray-200"
                            placeholder="e.g., JavaScript, Project Management, Photoshop"
                          />
                          {formData.skills.length > 1 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                              onClick={() => removeArrayItem("skills", index)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      ))}

                      <Button
                        type="button"
                        variant="outline"
                        className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                        onClick={() => addArrayItem("skills")}
                      >
                        Add Another Skill
                      </Button>
                    </div>
                  </TabsContent>

                  {/* Languages */}
                  <TabsContent value="languages" className="mt-0 space-y-6">
                    {formData.languages.map((lang, index) => (
                      <div key={index} className="space-y-4">
                        {index > 0 && <Separator className="bg-gray-700 my-6" />}

                        <div className="flex justify-between items-center">
                          <h3 className="text-white font-medium">Language #{index + 1}</h3>
                          {index > 0 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                              onClick={() => removeArrayItem("languages", index)}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Remove
                            </Button>
                          )}
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor={`language-${index}`} className="text-gray-300 mb-2 block">
                              Language
                            </Label>
                            <Input
                              id={`language-${index}`}
                              value={lang.language}
                              onChange={(e) => handleArrayInputChange("languages", index, "language", e.target.value)}
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                              placeholder="English, Spanish, etc."
                            />
                          </div>
                          <div>
                            <Label htmlFor={`proficiency-${index}`} className="text-gray-300 mb-2 block">
                              Proficiency
                            </Label>
                            <Select
                              value={lang.proficiency}
                              onValueChange={(value) =>
                                handleArrayInputChange("languages", index, "proficiency", value)
                              }
                            >
                              <SelectTrigger className="bg-gray-800/50 border-gray-700 text-gray-200">
                                <SelectValue placeholder="Select proficiency level" />
                              </SelectTrigger>
                              <SelectContent className="bg-gray-800 border-gray-700 text-gray-200">
                                <SelectItem value="native">Native</SelectItem>
                                <SelectItem value="fluent">Fluent</SelectItem>
                                <SelectItem value="advanced">Advanced</SelectItem>
                                <SelectItem value="intermediate">Intermediate</SelectItem>
                                <SelectItem value="basic">Basic</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                    ))}

                    <Button
                      type="button"
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                      onClick={() => addArrayItem("languages")}
                    >
                      <Languages className="h-4 w-4 mr-2" />
                      Add Another Language
                    </Button>
                  </TabsContent>

                  {/* Certifications */}
                  <TabsContent value="certifications" className="mt-0 space-y-6">
                    {formData.certifications.map((cert, index) => (
                      <div key={index} className="space-y-4">
                        {index > 0 && <Separator className="bg-gray-700 my-6" />}

                        <div className="flex justify-between items-center">
                          <h3 className="text-white font-medium">Certification #{index + 1}</h3>
                          {index > 0 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                              onClick={() => removeArrayItem("certifications", index)}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Remove
                            </Button>
                          )}
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor={`certName-${index}`} className="text-gray-300 mb-2 block">
                              Certification Name
                            </Label>
                            <Input
                              id={`certName-${index}`}
                              value={cert.name}
                              onChange={(e) => handleArrayInputChange("certifications", index, "name", e.target.value)}
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                              placeholder="AWS Certified Solutions Architect"
                            />
                          </div>
                          <div>
                            <Label htmlFor={`issuer-${index}`} className="text-gray-300 mb-2 block">
                              Issuing Organization
                            </Label>
                            <Input
                              id={`issuer-${index}`}
                              value={cert.issuer}
                              onChange={(e) =>
                                handleArrayInputChange("certifications", index, "issuer", e.target.value)
                              }
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                              placeholder="Amazon Web Services"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor={`certDate-${index}`} className="text-gray-300 mb-2 block">
                              Issue Date
                            </Label>
                            <Input
                              id={`certDate-${index}`}
                              type="month"
                              value={cert.date}
                              onChange={(e) => handleArrayInputChange("certifications", index, "date", e.target.value)}
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                            />
                          </div>
                          <div>
                            <Label htmlFor={`expires-${index}`} className="text-gray-300 mb-2 block">
                              Expiration Date (if applicable)
                            </Label>
                            <Input
                              id={`expires-${index}`}
                              type="month"
                              value={cert.expires}
                              onChange={(e) =>
                                handleArrayInputChange("certifications", index, "expires", e.target.value)
                              }
                              className="bg-gray-800/50 border-gray-700 text-gray-200"
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor={`certDescription-${index}`} className="text-gray-300 mb-2 block">
                            Description
                          </Label>
                          <Textarea
                            id={`certDescription-${index}`}
                            value={cert.description}
                            onChange={(e) =>
                              handleArrayInputChange("certifications", index, "description", e.target.value)
                            }
                            className="bg-gray-800/50 border-gray-700 text-gray-200"
                            placeholder="Briefly describe what this certification covers..."
                          />
                        </div>
                      </div>
                    ))}

                    <Button
                      type="button"
                      variant="outline"
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                      onClick={() => addArrayItem("certifications")}
                    >
                      <Award className="h-4 w-4 mr-2" />
                      Add Another Certification
                    </Button>
                  </TabsContent>
                </form>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500"
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Profile
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

