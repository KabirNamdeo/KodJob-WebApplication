import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Check if the user is authenticated for protected routes
  const isAuthenticated = request.cookies.has("kodjob_user")
  const isAuthPage = request.nextUrl.pathname === "/"

  // Redirect to login if accessing dashboard without authentication
  if (!isAuthenticated && request.nextUrl.pathname.startsWith("/dashboard")) {
    return NextResponse.redirect(new URL("/", request.url))
  }

  // Redirect to dashboard if already authenticated and trying to access login
  if (isAuthenticated && isAuthPage) {
    return NextResponse.redirect(new URL("/dashboard", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/", "/dashboard/:path*"],
}

