export type UserType = {
  id: string
  username: string
  password?: string
  name: string
  email?: string
}

export type JobType = {
  id: string
  title: string
  company: string
  location: string
  type: string
  salary: string
  posted: string
  description: string
  skills?: string[]
  eligibilityCriteria?: string[]
}

export type ContestType = {
  id: string
  title: string
  organizer: string
  type: string
  date: string
  duration: string
  participants: string
  status: "Upcoming" | "Active" | "Ended"
  startsIn: string
  skills?: string[]
}

export type OpportunityType = {
  id: string
  title: string
  company: string
  type: string
  location: string
  deadline: string
  applicants: string
  skills?: string[]
  stipend?: string
}

export type PreparationResourceType = {
  id: string
  title: string
  category: string
  description: string
  level: string
  type: string
  duration: string
  rating: number
  reviews: number
}

export type CareerGuidanceType = {
  id: string
  title: string
  category: string
  description: string
  author: string
  publishDate: string
  readTime: string
}

export type InspirationQuoteType = {
  id: string
  quote: string
  author: string
}

