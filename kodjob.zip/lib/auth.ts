import type { UserType } from "./types"

// Mock user data (in a real app, this would be stored in a database)
const users: UserType[] = [
  {
    id: "1",
    username: "demo",
    password: "password", // In a real app, this would be hashed
    name: "Demo User",
    email: "demo@example.com",
  },
  {
    id: "2",
    username: "admin",
    password: "admin123",
    name: "Admin User",
    email: "admin@example.com",
  },
]

// Mock user profiles
const userProfiles: Record<string, any> = {
  "1": {
    fullName: "Demo User",
    email: "demo@example.com",
    phone: "+1 (555) 123-4567",
    location: "New York, NY",
    website: "https://demo-portfolio.com",
    bio: "Experienced software developer with a passion for creating user-friendly applications.",
    education: [
      {
        degree: "Bachelor of Science",
        institution: "University of Technology",
        fieldOfStudy: "Computer Science",
        startDate: "2015-09",
        endDate: "2019-05",
        description: "Graduated with honors. Specialized in web development and artificial intelligence.",
      },
    ],
    experience: [
      {
        title: "Frontend Developer",
        company: "Tech Solutions Inc.",
        location: "New York, NY",
        startDate: "2019-06",
        endDate: "",
        current: true,
        description: "Developing responsive web applications using React, Next.js, and TypeScript.",
      },
      {
        title: "Web Development Intern",
        company: "Digital Creations",
        location: "Boston, MA",
        startDate: "2018-05",
        endDate: "2018-08",
        current: false,
        description: "Assisted in developing and maintaining client websites.",
      },
    ],
    skills: ["JavaScript", "React", "TypeScript", "HTML", "CSS", "Node.js", "Git"],
    languages: [
      { language: "English", proficiency: "native" },
      { language: "Spanish", proficiency: "intermediate" },
    ],
    certifications: [
      {
        name: "AWS Certified Developer",
        issuer: "Amazon Web Services",
        date: "2020-03",
        expires: "2023-03",
        description: "Certification for developing applications on AWS.",
      },
    ],
    resume: true,
  },
  "2": {
    fullName: "Admin User",
    email: "admin@example.com",
    phone: "+1 (555) 987-6543",
    location: "San Francisco, CA",
    website: "",
    bio: "Experienced project manager with a background in software development.",
    education: [
      {
        degree: "Master of Business Administration",
        institution: "Business University",
        fieldOfStudy: "Technology Management",
        startDate: "2016-09",
        endDate: "2018-05",
        description: "",
      },
    ],
    experience: [
      {
        title: "Project Manager",
        company: "Enterprise Solutions",
        location: "San Francisco, CA",
        startDate: "2018-06",
        endDate: "",
        current: true,
        description: "Managing software development projects and teams.",
      },
    ],
    skills: ["Project Management", "Agile", "Scrum", "Team Leadership", "Budgeting"],
    languages: [{ language: "English", proficiency: "native" }],
    certifications: [
      {
        name: "PMP Certification",
        issuer: "Project Management Institute",
        date: "2019-01",
        expires: "",
        description: "Professional Project Management certification.",
      },
    ],
    resume: true,
  },
}

export const authenticateUser = async (username: string, password: string): Promise<UserType | null> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      const user = users.find((u) => u.username.toLowerCase() === username.toLowerCase() && u.password === password)

      if (user) {
        // Don't return the password to the client
        const { password, ...userWithoutPassword } = user
        resolve(userWithoutPassword as UserType)
      } else {
        resolve(null)
      }
    }, 800)
  })
}

export const registerUser = async (username: string, password: string, name: string): Promise<boolean> => {
  // Check if username already exists
  const existingUser = users.find((u) => u.username.toLowerCase() === username.toLowerCase())

  if (existingUser) {
    return false
  }

  // In a real app, this would add the user to a database
  const newUser: UserType = {
    id: (users.length + 1).toString(),
    username,
    password, // In a real app, this would be hashed
    name,
    email: `${username}@example.com`, // Mock email
  }

  users.push(newUser)

  // Create an empty profile for the new user
  userProfiles[newUser.id] = {
    fullName: name,
    email: `${username}@example.com`,
    phone: "",
    location: "",
    website: "",
    bio: "",
    education: [
      {
        degree: "",
        institution: "",
        fieldOfStudy: "",
        startDate: "",
        endDate: "",
        description: "",
      },
    ],
    experience: [
      {
        title: "",
        company: "",
        location: "",
        startDate: "",
        endDate: "",
        current: false,
        description: "",
      },
    ],
    skills: [""],
    languages: [{ language: "", proficiency: "" }],
    certifications: [{ name: "", issuer: "", date: "", expires: "", description: "" }],
    resume: false,
  }

  return true
}

export const requestPasswordReset = async (username: string): Promise<boolean> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      const user = users.find((u) => u.username.toLowerCase() === username.toLowerCase())

      if (user) {
        // In a real app, this would generate a token and send an email
        console.log(`Password reset requested for ${user.email}`)
        resolve(true)
      } else {
        resolve(false)
      }
    }, 1000)
  })
}

export const resetPassword = async (token: string, newPassword: string): Promise<boolean> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      // In a real app, this would validate the token and update the user's password
      console.log(`Password reset with token: ${token}`)
      resolve(true)
    }, 1000)
  })
}

export const getUserProfile = async (userId: string): Promise<any> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      const profile = userProfiles[userId] || null
      resolve(profile)
    }, 800)
  })
}

export const updateUserProfile = async (userId: string, profileData: any): Promise<boolean> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      userProfiles[userId] = {
        ...profileData,
        resume: true, // Assume resume is uploaded when profile is updated
      }
      resolve(true)
    }, 1200)
  })
}

