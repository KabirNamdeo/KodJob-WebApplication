import type {
  JobType,
  ContestType,
  OpportunityType,
  PreparationResourceType,
  CareerGuidanceType,
  InspirationQuoteType,
} from "./types"

// Mock job data
const mockJobs: JobType[] = [
  {
    id: "1",
    title: "ServiceNow Developer Intern",
    company: "ServiceNow",
    location: "Bengaluru",
    type: "Full-time",
    salary: "4 LPA",
    posted: "3 days ago",
    description:
      "We are looking for a ServiceNow Developer Intern to join our team and help build and maintain our ServiceNow platform. The ideal candidate should have knowledge of JavaScript and be eager to learn ServiceNow development.",
    skills: ["Java", "JavaScript", "ServiceNow"],
    eligibilityCriteria: [
      "Bachelor's degree in Computer Science or related field",
      "Knowledge of JavaScript",
      "Problem-solving skills",
    ],
  },
  {
    id: "2",
    title: "Associate Database Administrator (DBA)",
    company: "Oracle",
    location: "Mumbai, Bengaluru",
    type: "Full-time",
    salary: "6 LPA",
    posted: "4 days ago",
    description:
      "Join our team as a Database Administrator to help manage and optimize our database systems. You will be responsible for database design, implementation, maintenance, and performance tuning.",
    skills: ["SQL", "Oracle", "Python", "Database Management"],
    eligibilityCriteria: [
      "Bachelor's degree in Computer Science",
      "Knowledge of SQL and database concepts",
      "Problem-solving skills",
    ],
  },
  {
    id: "3",
    title: "Trainee Tester & Functional Analyst",
    company: "TCS",
    location: "Bangalore",
    type: "Full-time",
    salary: "3.5 LPA",
    posted: "4 days ago",
    description:
      "Looking for a detail-oriented Trainee Tester to join our quality assurance team. You will be responsible for creating and executing test cases, identifying bugs, and ensuring software quality.",
    skills: ["Core Java", "Manual Testing", "Automation"],
    eligibilityCriteria: [
      "Bachelor's degree in Computer Science or related field",
      "Basic knowledge of testing methodologies",
      "Attention to detail",
    ],
  },
  {
    id: "4",
    title: "SDET Intern",
    company: "Townhall",
    location: "Hyderabad",
    type: "Internship",
    salary: "4 LPA",
    posted: "5 days ago",
    description:
      "Join our QA team as an SDET Intern to help build and maintain our automated testing framework. You will be working with Selenium, Java, and other testing tools to ensure software quality.",
    skills: ["Selenium", "Core Java", "Manual Testing"],
    eligibilityCriteria: [
      "Currently pursuing or recently graduated with a degree in Computer Science",
      "Knowledge of Java",
      "Interest in software testing",
    ],
  },
  {
    id: "5",
    title: "Fullstack Developer",
    company: "Kristal Ball Smart",
    location: "Bangalore",
    type: "Full-time",
    salary: "1.80 LPA",
    posted: "5 days ago",
    description:
      "We're looking for a Fullstack Developer to help build and maintain our web applications. You will be working with both frontend and backend technologies to deliver high-quality software.",
    skills: ["Core Java", "Adv Java", "Manual Testing", "JavaScript", "React", "Node.js"],
    eligibilityCriteria: [
      "Bachelor's degree in Computer Science or related field",
      "Experience with JavaScript and Java",
      "Knowledge of web development",
    ],
  },
  {
    id: "6",
    title: "Graduate Engineer",
    company: "Mavenir",
    location: "Bangalore",
    type: "Full-time",
    salary: "8 LPA",
    posted: "7 days ago",
    description:
      "Join our engineering team as a Graduate Engineer to work on cutting-edge telecommunications solutions. You will be involved in designing, developing, and testing software for our telecom products.",
    skills: ["Core Java", "Adv Java", "Java Frameworks", "Python"],
    eligibilityCriteria: [
      "Bachelor's or Master's degree in Computer Science or related field",
      "Strong programming skills",
      "Knowledge of software development lifecycle",
    ],
  },
  {
    id: "7",
    title: "QA Engineer",
    company: "Tinvio",
    location: "Work From Home",
    type: "Full-time",
    salary: "6 LPA",
    posted: "8 days ago",
    description:
      "We're looking for a QA Engineer to ensure the quality of our software products. You will be responsible for creating and executing test plans, identifying bugs, and working with developers to resolve issues.",
    skills: ["Manual Testing", "Automation Testing", "JIRA"],
    eligibilityCriteria: [
      "Bachelor's degree in Computer Science or related field",
      "Experience with software testing",
      "Knowledge of QA methodologies",
    ],
  },
  {
    id: "8",
    title: "Frontend Engineer - React",
    company: "Tinvio",
    location: "Work From Home",
    type: "Full-time",
    salary: "6 LPA",
    posted: "8 days ago",
    description:
      "Join our frontend team to build beautiful and responsive user interfaces using React. You will be responsible for implementing UI components, optimizing performance, and ensuring cross-browser compatibility.",
    skills: ["React", "JavaScript", "HTML", "CSS", "TypeScript"],
    eligibilityCriteria: [
      "Bachelor's degree in Computer Science or related field",
      "Experience with React and JavaScript",
      "Knowledge of modern frontend development",
    ],
  },
  {
    id: "9",
    title: "Associate System Engineer",
    company: "American Chase",
    location: "Indore",
    type: "Full-time",
    salary: "INR 3.21 LPA",
    posted: "10 days ago",
    description:
      "Looking for an Associate System Engineer to help maintain and optimize our IT infrastructure. You will be responsible for system administration, troubleshooting, and ensuring system reliability.",
    skills: ["Linux", "Windows Server", "Networking"],
    eligibilityCriteria: [
      "Bachelor's degree in Computer Science or related field",
      "Knowledge of operating systems",
      "Basic networking skills",
    ],
  },
]

// Mock contest data
const mockContests: ContestType[] = [
  {
    id: "1",
    title: "CodeCraft 2025",
    organizer: "Google",
    type: "Algorithms",
    date: "April 15, 2025",
    duration: "3 hours",
    participants: "5,000+",
    status: "Upcoming",
    startsIn: "2 weeks",
    skills: ["Data Structures", "Algorithms", "Problem Solving"],
  },
  {
    id: "2",
    title: "Hackathon for Good",
    organizer: "Microsoft",
    type: "Hackathon",
    date: "May 10-12, 2025",
    duration: "48 hours",
    participants: "2,500+",
    status: "Upcoming",
    startsIn: "1 month",
    skills: ["Web Development", "AI/ML", "Cloud Computing"],
  },
  {
    id: "3",
    title: "Data Science Challenge",
    organizer: "Kaggle",
    type: "Data Science",
    date: "March 30, 2025",
    duration: "2 weeks",
    participants: "3,200+",
    status: "Active",
    startsIn: "",
    skills: ["Machine Learning", "Data Analysis", "Python"],
  },
  {
    id: "4",
    title: "Frontend Showdown",
    organizer: "Vercel",
    type: "Web Development",
    date: "April 5, 2025",
    duration: "24 hours",
    participants: "1,800+",
    status: "Upcoming",
    startsIn: "3 weeks",
    skills: ["React", "Next.js", "CSS", "UI/UX"],
  },
  {
    id: "5",
    title: "Competitive Programming Contest",
    organizer: "CodeForces",
    type: "Algorithms",
    date: "March 25, 2025",
    duration: "2.5 hours",
    participants: "10,000+",
    status: "Upcoming",
    startsIn: "1 week",
    skills: ["Algorithms", "Data Structures", "C++", "Java"],
  },
  {
    id: "6",
    title: "Mobile App Innovation Challenge",
    organizer: "Apple",
    type: "Mobile Development",
    date: "June 5-7, 2025",
    duration: "72 hours",
    participants: "1,500+",
    status: "Upcoming",
    startsIn: "2 months",
    skills: ["iOS Development", "Swift", "UI/UX Design"],
  },
]

// Mock opportunity data
const mockOpportunities: OpportunityType[] = [
  {
    id: "1",
    title: "Google Summer of Code 2025",
    company: "Google",
    type: "Open Source",
    location: "Remote",
    deadline: "April 10, 2025",
    applicants: "15,000+",
    skills: ["Programming", "Open Source", "Git"],
    stipend: "$6,000 for 3 months",
  },
  {
    id: "2",
    title: "Microsoft Research Internship",
    company: "Microsoft",
    type: "Internship",
    location: "Redmond, WA (Remote Option)",
    deadline: "March 30, 2025",
    applicants: "8,000+",
    skills: ["AI/ML", "Research", "Python"],
    stipend: "$8,000 per month",
  },
  {
    id: "3",
    title: "Women in Tech Scholarship",
    company: "Anita Borg Institute",
    type: "Scholarship",
    location: "Global",
    deadline: "May 15, 2025",
    applicants: "5,000+",
    skills: ["Computer Science", "Leadership"],
    stipend: "$10,000",
  },
  {
    id: "4",
    title: "AWS Cloud Computing Bootcamp",
    company: "Amazon",
    type: "Training",
    location: "Online",
    deadline: "April 5, 2025",
    applicants: "3,500+",
    skills: ["Cloud Computing", "AWS", "DevOps"],
    stipend: "Free Training + Certification",
  },
  {
    id: "5",
    title: "Open Source Mentorship Program",
    company: "Linux Foundation",
    type: "Mentorship",
    location: "Remote",
    deadline: "March 25, 2025",
    applicants: "2,000+",
    skills: ["Linux", "Open Source", "C/C++"],
    stipend: "$5,000 for 3 months",
  },
]

// Mock preparation resources
const mockPreparationResources: PreparationResourceType[] = [
  {
    id: "1",
    title: "Data Structures and Algorithms Masterclass",
    category: "Data Structures",
    description: "Comprehensive course covering all essential data structures and algorithms for technical interviews.",
    level: "Intermediate",
    type: "Course",
    duration: "40 hours",
    rating: 4.8,
    reviews: 1250,
  },
  {
    id: "2",
    title: "System Design Interview Guide",
    category: "System Design",
    description: "Learn how to approach and solve system design problems in technical interviews.",
    level: "Advanced",
    type: "eBook",
    duration: "10 hours",
    rating: 4.9,
    reviews: 850,
  },
  {
    id: "3",
    title: "Operating Systems Fundamentals",
    category: "Operating Systems",
    description: "Core concepts of operating systems explained with practical examples.",
    level: "Intermediate",
    type: "Video Course",
    duration: "25 hours",
    rating: 4.7,
    reviews: 720,
  },
  {
    id: "4",
    title: "Database Concepts and SQL Mastery",
    category: "Database",
    description: "Comprehensive guide to database concepts, SQL, and optimization techniques.",
    level: "Beginner to Advanced",
    type: "Interactive Course",
    duration: "30 hours",
    rating: 4.6,
    reviews: 950,
  },
  {
    id: "5",
    title: "Web Development Bootcamp",
    category: "Web Development",
    description: "Full-stack web development from basics to advanced concepts.",
    level: "Beginner to Intermediate",
    type: "Bootcamp",
    duration: "60 hours",
    rating: 4.8,
    reviews: 1500,
  },
  {
    id: "6",
    title: "Machine Learning Fundamentals",
    category: "Machine Learning",
    description: "Introduction to machine learning algorithms and practical implementations.",
    level: "Intermediate",
    type: "Course",
    duration: "45 hours",
    rating: 4.7,
    reviews: 1100,
  },
]

// Mock career guidance
const mockCareerGuidance: CareerGuidanceType[] = [
  {
    id: "1",
    title: "Mastering the Technical Interview",
    category: "Interview",
    description: "Comprehensive guide to acing technical interviews at top tech companies.",
    author: "Jane Smith, Ex-Google Interviewer",
    publishDate: "February 15, 2025",
    readTime: "15 min read",
  },
  {
    id: "2",
    title: "Building an ATS-Friendly Resume",
    category: "Resume",
    description: "Learn how to optimize your resume to pass through Applicant Tracking Systems.",
    author: "Michael Johnson, HR Tech Specialist",
    publishDate: "March 5, 2025",
    readTime: "10 min read",
  },
  {
    id: "3",
    title: "From Junior to Senior Developer: A Roadmap",
    category: "Career Path",
    description: "Strategic guide to advancing your career from junior to senior developer roles.",
    author: "David Chen, Engineering Manager",
    publishDate: "January 20, 2025",
    readTime: "20 min read",
  },
  {
    id: "4",
    title: "Negotiating Your Tech Salary",
    category: "Negotiation",
    description: "Tactics and strategies for negotiating the best compensation package.",
    author: "Sarah Williams, Career Coach",
    publishDate: "February 28, 2025",
    readTime: "12 min read",
  },
  {
    id: "5",
    title: "Transitioning to a Tech Career",
    category: "Career Path",
    description: "Guide for professionals looking to switch to a career in technology.",
    author: "Robert Garcia, Career Transition Specialist",
    publishDate: "March 10, 2025",
    readTime: "18 min read",
  },
  {
    id: "6",
    title: "Building a Personal Brand in Tech",
    category: "Personal Development",
    description: "How to establish yourself as a thought leader in the tech industry.",
    author: "Emily Zhang, Tech Influencer",
    publishDate: "January 5, 2025",
    readTime: "15 min read",
  },
]

// Mock inspiration quotes
const mockInspirationQuotes: InspirationQuoteType[] = [
  {
    id: "1",
    quote: "Your time is limited, so don't waste it living someone else's life.",
    author: "Steve Jobs",
  },
  {
    id: "2",
    quote: "The best way to predict the future is to invent it.",
    author: "Alan Kay",
  },
  {
    id: "3",
    quote: "Innovation distinguishes between a leader and a follower.",
    author: "Steve Jobs",
  },
  {
    id: "4",
    quote: "The only way to do great work is to love what you do.",
    author: "Steve Jobs",
  },
  {
    id: "5",
    quote: "Move fast and break things. Unless you are breaking stuff, you are not moving fast enough.",
    author: "Mark Zuckerberg",
  },
  {
    id: "6",
    quote:
      "The biggest risk is not taking any risk. In a world that's changing quickly, the only strategy that is guaranteed to fail is not taking risks.",
    author: "Mark Zuckerberg",
  },
  {
    id: "7",
    quote: "Don't compare yourself with anyone in this world. If you do so, you are insulting yourself.",
    author: "Bill Gates",
  },
  {
    id: "8",
    quote: "I choose a lazy person to do a hard job. Because a lazy person will find an easy way to do it.",
    author: "Bill Gates",
  },
  {
    id: "9",
    quote: "When something is important enough, you do it even if the odds are not in your favor.",
    author: "Elon Musk",
  },
  {
    id: "10",
    quote: "Some people don't like change, but you need to embrace change if the alternative is disaster.",
    author: "Elon Musk",
  },
  {
    id: "11",
    quote:
      "If you get up in the morning and think the future is going to be better, it is a bright day. Otherwise, it's not.",
    author: "Elon Musk",
  },
  {
    id: "12",
    quote: "Sometimes life is going to hit you in the head with a brick. Don't lose faith.",
    author: "Steve Jobs",
  },
]

// Function to fetch jobs
export const fetchJobs = async (): Promise<JobType[]> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockJobs)
    }, 1500)
  })
}

// Function to fetch a job by ID
export const getJobById = async (id: string): Promise<JobType | null> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      const job = mockJobs.find((job) => job.id === id) || null
      resolve(job)
    }, 800)
  })
}

// Function to fetch contests
export const getContests = async (): Promise<ContestType[]> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockContests)
    }, 1000)
  })
}

// Function to fetch opportunities
export const getOpportunities = async (): Promise<OpportunityType[]> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockOpportunities)
    }, 1200)
  })
}

// Function to fetch preparation resources
export const getPreparationResources = async (): Promise<PreparationResourceType[]> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockPreparationResources)
    }, 900)
  })
}

// Function to fetch career guidance
export const getCareerGuidance = async (): Promise<CareerGuidanceType[]> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockCareerGuidance)
    }, 1100)
  })
}

// Function to fetch inspiration quotes
export const getInspirationQuotes = async (): Promise<InspirationQuoteType[]> => {
  // Simulate API call delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockInspirationQuotes)
    }, 700)
  })
}

